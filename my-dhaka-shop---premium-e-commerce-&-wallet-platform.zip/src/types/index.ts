export type Language = 'bn' | 'en';

export interface User {
  id: string;
  name: string;
  email: string;
  phone?: string;
  avatar?: string;
  role: 'customer' | 'admin';
  googleId?: string;
  isGoogleUser?: boolean;
  walletBalance: number;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface Category {
  id: string;
  nameBn: string;
  nameEn: string;
  slug: string;
  icon: string;
  image: string;
  isActive: boolean;
  productCount?: number;
}

export interface Product {
  id: string;
  nameBn: string;
  nameEn: string;
  categoryId: string;
  slug: string;
  price: number;
  originalPrice: number;
  discountPercentage: number;
  stock: number;
  isFeatured: boolean;
  isActive: boolean;
  images: string[];
  thumbnail: string;
  descriptionBn: string;
  descriptionEn: string;
  specifications: Record<string, string>;
  rating: number;
  reviewCount: number;
  createdAt: string;
}

export interface Banner {
  id: string;
  titleBn: string;
  titleEn: string;
  subtitleBn: string;
  subtitleEn: string;
  badgeBn?: string;
  badgeEn?: string;
  image: string;
  link: string;
  buttonTextBn: string;
  buttonTextEn: string;
  isActive: boolean;
  sortOrder: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'out_for_delivery'
  | 'delivered'
  | 'cancelled'
  | 'returned';

export interface OrderItem {
  productId: string;
  productNameBn: string;
  productNameEn: string;
  productThumbnail: string;
  price: number;
  quantity: number;
  subtotal: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  userId: string;
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  alternativePhone?: string;
  district: string;
  thana: string;
  fullAddress: string;
  deliveryZone: 'inside_dhaka' | 'outside_dhaka';
  orderNotes?: string;
  items: OrderItem[];
  itemsSubtotal: number;
  deliveryCharge: number; // Prepaid from Wallet
  walletDeductedAmount: number;
  remainingCodAmount: number; // Cash to pay to delivery agent
  totalOrderValue: number; // itemsSubtotal + deliveryCharge
  status: OrderStatus;
  deliveryChargeRefunded?: boolean;
  paymentMethod: 'Prepaid Delivery + COD';
  createdAt: string;
  updatedAt: string;
}

export type TransactionType = 'credit' | 'debit' | 'refund' | 'adjustment';
export type TransactionStatus = 'completed' | 'pending' | 'failed';

export interface WalletTransaction {
  id: string;
  transactionRef: string;
  userId: string;
  userName: string;
  type: TransactionType;
  title: string;
  amount: number;
  status: TransactionStatus;
  balanceAfter: number;
  paymentGateway?: 'NobabPay' | 'System' | 'Manual';
  gatewayTxnId?: string;
  orderId?: string;
  note?: string;
  createdAt: string;
}

export interface WebsiteSettings {
  businessName: string;
  websiteName: string;
  websiteDomain: string;
  businessPhone: string;
  businessEmail: string;
  businessAddress: string;
  currency: string;
  currencySymbol: string;
  deliveryChargeInsideDhaka: number;
  deliveryChargeOutsideDhaka: number;
  nobabPayBrandKey: string;
  nobabPayCallbackUrl: string;
  nobabPayMode: 'live' | 'sandbox';
  googleClientId: string;
  defaultLanguage: Language;
  cronJobCommand: string;
  fbUrl: string;
  youtubeUrl: string;
  whatsappNumber: string;
}

export interface AdminNotification {
  id: string;
  title: string;
  message: string;
  orderId?: string;
  amount?: number;
  isRead: boolean;
  createdAt: string;
}

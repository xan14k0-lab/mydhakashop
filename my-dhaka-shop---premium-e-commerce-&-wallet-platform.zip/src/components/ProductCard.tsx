import React from 'react';
import { ShoppingCart, Star, Eye, ShieldCheck, Zap } from 'lucide-react';
import { Product, Language } from '../types';

interface ProductCardProps {
  product: Product;
  currentLanguage: Language;
  onAddToCart: (product: Product) => void;
  onQuickOrder: (product: Product) => void;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currentLanguage,
  onAddToCart,
  onQuickOrder,
  onViewDetails,
}) => {
  const isOutOfStock = product.stock <= 0;

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/90 hover:border-emerald-300 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden relative">
      {/* Top badges */}
      <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
        {product.discountPercentage > 0 && (
          <span className="px-2 py-0.5 bg-red-600 text-white font-black text-[11px] rounded-md shadow-xs">
            -{product.discountPercentage}%
          </span>
        )}
        {product.isFeatured && (
          <span className="px-2 py-0.5 bg-emerald-600 text-white font-bold text-[10px] rounded-md shadow-xs flex items-center gap-1">
            <Zap className="w-2.5 h-2.5" />
            হট ডিল
          </span>
        )}
      </div>

      {/* Thumbnail */}
      <div
        onClick={() => onViewDetails(product)}
        className="relative aspect-square overflow-hidden bg-slate-100 cursor-pointer"
      >
        <img
          src={product.thumbnail}
          alt={product.nameBn}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        {/* Quick view overlay icon */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <button
            type="button"
            className="p-2.5 rounded-full bg-white text-slate-800 shadow-md hover:bg-emerald-600 hover:text-white transition-colors"
            title="বিস্তারিত দেখুন"
          >
            <Eye className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-3.5 md:p-4 flex flex-col grow justify-between">
        <div>
          {/* Rating */}
          <div className="flex items-center gap-1.5 mb-1.5">
            <div className="flex items-center text-amber-400">
              <Star className="w-3.5 h-3.5 fill-current" />
            </div>
            <span className="text-xs font-bold text-slate-700">{product.rating}</span>
            <span className="text-[11px] text-slate-400">({product.reviewCount})</span>
            <span className="ml-auto text-[10px] text-slate-500 font-medium">
              {isOutOfStock ? (
                <span className="text-red-500 font-bold">স্টক শেষ</span>
              ) : (
                <span className="text-emerald-700">স্টক: {product.stock} টি</span>
              )}
            </span>
          </div>

          {/* Title */}
          <h4
            onClick={() => onViewDetails(product)}
            className="font-bold text-xs md:text-sm text-slate-800 hover:text-emerald-600 line-clamp-2 transition-colors cursor-pointer leading-snug min-h-[2.4rem]"
          >
            {currentLanguage === 'bn' ? product.nameBn : product.nameEn}
          </h4>

          {/* Price */}
          <div className="mt-2.5 flex items-baseline gap-2">
            <span className="text-base md:text-lg font-black text-slate-900">
              ৳{product.price.toLocaleString()}
            </span>
            {product.originalPrice > product.price && (
              <span className="text-xs text-slate-400 line-through">
                ৳{product.originalPrice.toLocaleString()}
              </span>
            )}
          </div>

          {/* Prepaid delivery info tag */}
          <div className="mt-2 py-1 px-2 bg-emerald-50/80 rounded-md border border-emerald-100 flex items-center gap-1 text-[10px] text-emerald-800">
            <ShieldCheck className="w-3 h-3 text-emerald-600 shrink-0" />
            <span className="truncate">অগ্রিম ডেলিভারি চার্জ + ক্যাশ অন ডেলিভারি</span>
          </div>
        </div>

        {/* Buttons */}
        <div className="mt-3.5 grid grid-cols-2 gap-2 pt-2 border-t border-slate-100">
          <button
            type="button"
            disabled={isOutOfStock}
            onClick={() => onAddToCart(product)}
            className="py-2 px-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50 cursor-pointer"
            title="Add to cart"
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">কার্ট</span>
          </button>

          <button
            type="button"
            disabled={isOutOfStock}
            onClick={() => onQuickOrder(product)}
            className="py-2 px-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors shadow-xs shadow-emerald-600/20 disabled:opacity-50 cursor-pointer"
          >
            <span>অর্ডার করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import {
  User as UserIcon,
  Wallet,
  Package,
  History,
  Lock,
  LogOut,
  PlusCircle,
  Clock,
  CheckCircle,
  Truck,
  ArrowUpRight,
  ArrowDownLeft,
  RotateCcw,
  ShieldCheck,
  AlertCircle,
} from 'lucide-react';
import { User, Order, WalletTransaction, Language } from '../types';
import { storageService } from '../services/storageService';

interface CustomerDashboardProps {
  currentUser: User | null;
  initialTab?: string;
  onClose: () => void;
  onOpenNobabPay: (amount?: number) => void;
  currentLanguage: Language;
}

export const CustomerDashboard: React.FC<CustomerDashboardProps> = ({
  currentUser,
  initialTab = 'profile',
  onClose,
  onOpenNobabPay,
  currentLanguage,
}) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'wallet' | 'orders' | 'security'>(
    (initialTab as 'profile' | 'wallet' | 'orders' | 'security') || 'profile'
  );

  const [filterType, setFilterType] = useState<string>('all');
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState('');

  if (!currentUser) return null;

  const orders = storageService.getOrders().filter((o) => o.userId === currentUser.id);
  const transactions = storageService.getWalletTransactions(currentUser.id);

  const filteredTransactions = transactions.filter((t) => {
    if (filterType === 'all') return true;
    return t.type === filterType;
  });

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-800">অপেক্ষমাণ (Pending)</span>;
      case 'confirmed':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 text-blue-800">নিশ্চিত (Confirmed)</span>;
      case 'processing':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-800">প্রক্রিয়াধীন (Processing)</span>;
      case 'shipped':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-indigo-100 text-indigo-800">শিপড (Shipped)</span>;
      case 'out_for_delivery':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-teal-100 text-teal-800">ডেলিভারিতে আছে</span>;
      case 'delivered':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">ডেলিভারড (Delivered)</span>;
      case 'cancelled':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-red-100 text-red-800">বাতিল (Cancelled)</span>;
      default:
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-800">{status}</span>;
    }
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword || newPassword.length < 6) {
      setPasswordMsg('পাসওয়ার্ড কমপক্ষে ৬ ডিজিটের হতে হবে');
      return;
    }
    setPasswordMsg('পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!');
    setNewPassword('');
    setTimeout(() => setPasswordMsg(''), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 md:p-6 overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 my-auto flex flex-col md:flex-row h-[90vh] max-h-[700px]">
        {/* Left Sidebar */}
        <div className="w-full md:w-64 bg-slate-900 text-white p-5 flex flex-col justify-between shrink-0">
          <div>
            {/* User Profile Glance */}
            <div className="flex items-center gap-3 pb-5 border-b border-white/10">
              <img
                src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'}
                alt={currentUser.name}
                className="w-12 h-12 rounded-2xl object-cover ring-2 ring-emerald-400"
              />
              <div className="min-w-0">
                <h3 className="font-bold text-sm text-white truncate">{currentUser.name}</h3>
                <span className="text-[11px] text-emerald-400 font-medium block">
                  {currentUser.isGoogleUser ? 'Google Verified' : 'Registered User'}
                </span>
              </div>
            </div>

            {/* Quick Wallet Balance Tile */}
            <div className="mt-4 p-3 bg-white/5 border border-white/10 rounded-2xl">
              <span className="text-[10px] text-slate-400 block">ডিজিটাল ওয়ালেট ব্যালেন্স</span>
              <div className="flex items-center justify-between mt-1">
                <span className="text-xl font-black text-emerald-400">৳{currentUser.walletBalance}</span>
                <button
                  type="button"
                  onClick={() => onOpenNobabPay(250)}
                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 rounded-lg text-[10px] font-bold text-white transition-colors cursor-pointer"
                >
                  + Add Money
                </button>
              </div>
            </div>

            {/* Nav Tabs */}
            <nav className="mt-5 space-y-1">
              <button
                type="button"
                onClick={() => setActiveTab('profile')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'profile'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <UserIcon className="w-4 h-4" />
                <span>আমার প্রোফাইল (Profile)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'orders'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Package className="w-4 h-4" />
                  <span>আমার অর্ডারসমূহ (Orders)</span>
                </div>
                {orders.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] bg-white/20 text-white font-mono">
                    {orders.length}
                  </span>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('wallet')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'wallet'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Wallet className="w-4 h-4" />
                <span>ওয়ালেট ও লেনদেন (Wallet)</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('security')}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                  activeTab === 'security'
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Lock className="w-4 h-4" />
                <span>পাসওয়ার্ড ও নিরাপত্তা</span>
              </button>
            </nav>
          </div>

          {/* Logout / Close buttons */}
          <div className="pt-4 border-t border-white/10 space-y-2">
            <button
              type="button"
              onClick={() => {
                storageService.logout();
                onClose();
              }}
              className="w-full flex items-center gap-2 px-3 py-2 text-xs text-red-400 hover:bg-red-500/10 rounded-xl transition-colors cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
              <span>লগআউট করুন</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="w-full py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-medium rounded-xl transition-colors"
            >
              ড্যাশবোর্ড বন্ধ করুন
            </button>
          </div>
        </div>

        {/* Right Main Content */}
        <div className="grow p-6 overflow-y-auto bg-slate-50">
          {/* TAB 1: Profile */}
          {activeTab === 'profile' && (
            <div className="space-y-5">
              <div>
                <h3 className="text-xl font-bold text-slate-900">কাস্টমার প্রোফাইল</h3>
                <p className="text-xs text-slate-500">আপনার ব্যক্তিগত তথ্য এবং লিঙ্কড অ্যাকাউন্ট</p>
              </div>

              <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
                <div className="flex items-center gap-4">
                  <img
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'}
                    alt={currentUser.name}
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-emerald-500/30"
                  />
                  <div>
                    <h4 className="font-bold text-base text-slate-800">{currentUser.name}</h4>
                    <p className="text-xs text-slate-500">{currentUser.email}</p>
                    {currentUser.isGoogleUser && (
                      <span className="inline-flex items-center gap-1 text-[11px] text-blue-600 font-medium bg-blue-50 px-2 py-0.5 rounded-md mt-1 border border-blue-200">
                        <CheckCircle className="w-3 h-3" />
                        Google Authenticated
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-100 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="text-slate-400 block text-[10px]">ফোন নম্বর</span>
                    <span className="font-semibold text-slate-800">{currentUser.phone || '01739376516'}</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="text-slate-400 block text-[10px]">অ্যাকাউন্ট স্ট্যাটাস</span>
                    <span className="font-bold text-emerald-600 uppercase">{currentUser.status}</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="text-slate-400 block text-[10px]">মোট অর্ডার</span>
                    <span className="font-semibold text-slate-800">{orders.length} টি</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl">
                    <span className="text-slate-400 block text-[10px]">ওয়ালেট ব্যালেন্স</span>
                    <span className="font-bold text-emerald-600">৳{currentUser.walletBalance}</span>
                  </div>
                </div>
              </div>

              {/* Delivery Charge System Notice */}
              <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-4 text-xs text-emerald-900 space-y-1.5">
                <div className="flex items-center gap-2 font-bold text-emerald-800">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>প্রিপেইড ডেলিভারি চার্জ ও ক্যাশ অন ডেলিভারি (COD) পলিসি:</span>
                </div>
                <p className="text-emerald-800 leading-relaxed">
                  মাই ঢাকা শপে যেকোনো অর্ডার করতে ডেলিভারি চার্জ আপনার ডিজিটাল ওয়ালেট থেকে অগ্রিম কর্তিত হয়। পণ্যের অবশিষ্ট মূল্য পণ্য হাতে পেয়ে কুরিয়ারম্যানকে সরাসরি ক্যাশ পরিশোধ করতে পারবেন।
                </p>
              </div>
            </div>
          )}

          {/* TAB 2: Orders */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-bold text-slate-900">আমার অর্ডারসমূহ ({orders.length})</h3>
                <p className="text-xs text-slate-500">আপনার অর্ডারের বর্তমান অবস্থা এবং ট্র্যাকিং তথ্য</p>
              </div>

              {orders.length === 0 ? (
                <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
                  <Package className="w-12 h-12 text-slate-300 mx-auto mb-2" />
                  <p className="text-sm font-semibold text-slate-700">কোনো অর্ডার পাওয়া যায়নি</p>
                  <p className="text-xs text-slate-400 mt-1">পণ্য পছন্দ করে এখনই অর্ডার করুন!</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((order) => (
                    <div
                      key={order.id}
                      className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-xs space-y-3"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-xs text-slate-900">
                              #{order.orderNumber}
                            </span>
                            {getStatusBadge(order.status)}
                          </div>
                          <span className="text-[11px] text-slate-400 mt-0.5 block">
                            তারিখ: {new Date(order.createdAt).toLocaleDateString('bn-BD', {
                              year: 'numeric',
                              month: 'short',
                              day: 'numeric',
                            })}
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="text-xs text-slate-400 block">ক্যাশ অন ডেলিভারি</span>
                          <span className="font-black text-sm text-emerald-700">৳{order.remainingCodAmount}</span>
                        </div>
                      </div>

                      {/* Items */}
                      <div className="space-y-2">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="flex items-center gap-3 text-xs">
                            <img
                              src={item.productThumbnail}
                              alt=""
                              className="w-10 h-10 rounded-lg object-cover border border-slate-100"
                            />
                            <div className="grow min-w-0">
                              <p className="font-semibold text-slate-800 truncate">{item.productNameBn}</p>
                              <p className="text-slate-500 text-[11px]">
                                ৳{item.price} × {item.quantity} = ৳{item.subtotal}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>

                      {/* Payment Breakdown */}
                      <div className="bg-slate-50 rounded-xl p-2.5 text-[11px] space-y-1 text-slate-600">
                        <div className="flex justify-between">
                          <span>ডেলিভারি ঠিকানা:</span>
                          <span className="font-medium text-slate-800">{order.fullAddress}, {order.thana}</span>
                        </div>
                        <div className="flex justify-between text-emerald-700 font-medium">
                          <span>অগ্রিম ওয়ালেট থেকে কর্তিত (ডেলিভারি চার্জ):</span>
                          <span>-৳{order.deliveryCharge} (পরিশোধিত)</span>
                        </div>
                        <div className="flex justify-between font-bold text-slate-900 border-t border-slate-200 pt-1">
                          <span>ক্যাশ অন ডেলিভারিতে প্রদেয়:</span>
                          <span>৳{order.remainingCodAmount}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: Wallet */}
          {activeTab === 'wallet' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-xl font-bold text-slate-900">ডিজিটাল ওয়ালেট ও লেনদেন</h3>
                  <p className="text-xs text-slate-500">নোবাবপে দিয়ে টাকা যোগ করুন এবং ট্রানজেকশন হিস্ট্রি দেখুন</p>
                </div>
                <button
                  type="button"
                  onClick={() => onOpenNobabPay(500)}
                  className="py-2 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>টাকা যোগ করুন (Add Money)</span>
                </button>
              </div>

              {/* Wallet Card */}
              <div className="bg-gradient-to-tr from-slate-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="text-xs text-emerald-400 font-medium tracking-wide">
                        MY DHAKA SHOP • DIGITAL WALLET
                      </span>
                      <h2 className="text-3xl font-black mt-2 text-white">৳{currentUser.walletBalance}</h2>
                    </div>
                    <div className="px-3 py-1 bg-white/10 rounded-full text-xs font-mono text-emerald-300 backdrop-blur-xs">
                      ID: {currentUser.id.slice(-6).toUpperCase()}
                    </div>
                  </div>

                  <div className="mt-6 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[10px]">অ্যাকাউন্ট হোল্ডার</span>
                      <span className="font-bold text-white">{currentUser.name}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-slate-400 block text-[10px]">পেমেন্ট গেটওয়ে</span>
                      <span className="font-bold text-emerald-400">NobabPay Verified</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Transaction History Filter */}
              <div className="flex items-center gap-2 pt-2">
                {['all', 'credit', 'debit', 'refund'].map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setFilterType(type)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold capitalize transition-colors cursor-pointer ${
                      filterType === type
                        ? 'bg-slate-900 text-white'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {type === 'all'
                      ? 'সকল লেনদেন'
                      : type === 'credit'
                      ? 'জমা (+)'
                      : type === 'debit'
                      ? 'কর্তন (-)'
                      : 'রিফান্ড'}
                  </button>
                ))}
              </div>

              {/* Transactions Table */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
                {filteredTransactions.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs">কোনো ট্রানজেকশন রেকর্ড নেই</div>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {filteredTransactions.map((t) => (
                      <div key={t.id} className="p-3.5 flex items-center justify-between text-xs hover:bg-slate-50 transition-colors">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                              t.type === 'credit'
                                ? 'bg-emerald-100 text-emerald-700'
                                : t.type === 'refund'
                                ? 'bg-blue-100 text-blue-700'
                                : 'bg-red-100 text-red-700'
                            }`}
                          >
                            {t.type === 'credit' ? (
                              <ArrowDownLeft className="w-4 h-4" />
                            ) : t.type === 'refund' ? (
                              <RotateCcw className="w-4 h-4" />
                            ) : (
                              <ArrowUpRight className="w-4 h-4" />
                            )}
                          </div>
                          <div>
                            <p className="font-bold text-slate-800">{t.title}</p>
                            <p className="text-[11px] text-slate-400 font-mono">
                              {t.transactionRef} • {new Date(t.createdAt).toLocaleDateString('bn-BD')}
                            </p>
                          </div>
                        </div>

                        <div className="text-right">
                          <span
                            className={`font-black text-sm block ${
                              t.type === 'credit' || t.type === 'refund'
                                ? 'text-emerald-600'
                                : 'text-red-600'
                            }`}
                          >
                            {t.type === 'credit' || t.type === 'refund' ? '+' : '-'}৳{t.amount}
                          </span>
                          <span className="text-[10px] text-slate-400">ব্যালেন্স: ৳{t.balanceAfter}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 4: Security */}
          {activeTab === 'security' && (
            <div className="space-y-4">
              <div>
                <h3 className="text-xl font-bold text-slate-900">পাসওয়ার্ড ও নিরাপত্তা</h3>
                <p className="text-xs text-slate-500">আপনার অ্যাকাউন্টের পাসওয়ার্ড পরিবর্তন করুন</p>
              </div>

              <div className="bg-white rounded-2xl p-5 border border-slate-200 max-w-md">
                {passwordMsg && (
                  <div className="mb-4 p-3 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs">
                    {passwordMsg}
                  </div>
                )}

                <form onSubmit={handleUpdatePassword} className="space-y-3 text-xs">
                  <div>
                    <label className="block font-medium text-slate-700 mb-1">নতুন পাসওয়ার্ড লিখুন:</label>
                    <input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="কমপক্ষে ৬ অক্ষর"
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition-colors cursor-pointer"
                  >
                    পাসওয়ার্ড পরিবর্তন করুন
                  </button>
                </form>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Category, Language } from '../types';
import { Watch, Shirt, Headphones, Home, Sparkles, Package } from 'lucide-react';

interface CategoryListProps {
  categories: Category[];
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
  currentLanguage: Language;
}

export const CategoryList: React.FC<CategoryListProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  currentLanguage,
}) => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Watch':
        return <Watch className="w-5 h-5 text-emerald-600" />;
      case 'Shirt':
        return <Shirt className="w-5 h-5 text-emerald-600" />;
      case 'Headphones':
        return <Headphones className="w-5 h-5 text-emerald-600" />;
      case 'Home':
        return <Home className="w-5 h-5 text-emerald-600" />;
      case 'Sparkles':
        return <Sparkles className="w-5 h-5 text-emerald-600" />;
      default:
        return <Package className="w-5 h-5 text-emerald-600" />;
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg md:text-xl font-bold text-slate-900 tracking-tight">
            {currentLanguage === 'bn' ? 'ক্যাটাগরি সমূহ' : 'Shop by Categories'}
          </h3>
          <p className="text-xs text-slate-500">
            {currentLanguage === 'bn'
              ? 'আপনার পছন্দের ক্যাটাগরি বেছে নিন'
              : 'Explore our top featured categories'}
          </p>
        </div>
        {selectedCategory && (
          <button
            onClick={() => onSelectCategory(null)}
            className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold cursor-pointer"
          >
            {currentLanguage === 'bn' ? 'সব ক্যাটাগরি দেখুন' : 'Show All'}
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 md:gap-4">
        {categories
          .filter((c) => c.isActive)
          .map((cat) => {
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(isSelected ? null : cat.id)}
                className={`group relative p-3 rounded-2xl border text-left transition-all duration-200 cursor-pointer overflow-hidden ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/70 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'border-slate-200/90 bg-white hover:border-emerald-300 hover:shadow-md'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-slate-100 group-hover:bg-emerald-100/60 flex items-center justify-center shrink-0 transition-colors">
                    {getIcon(cat.icon)}
                  </div>
                  <div className="min-w-0">
                    <h4 className="text-xs md:text-sm font-bold text-slate-800 group-hover:text-emerald-700 transition-colors truncate">
                      {currentLanguage === 'bn' ? cat.nameBn : cat.nameEn}
                    </h4>
                    <span className="text-[11px] text-slate-500 font-medium">
                      {cat.productCount ?? 0} {currentLanguage === 'bn' ? 'পণ্য' : 'items'}
                    </span>
                  </div>
                </div>
              </button>
            );
          })}
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import {
  X,
  MapPin,
  Phone,
  User as UserIcon,
  CreditCard,
  Wallet,
  AlertCircle,
  PlusCircle,
  CheckCircle2,
  Package,
  Truck,
  ShieldCheck,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { storageService } from '../services/storageService';
import { Product, User, Order } from '../types';
import { soundService } from '../services/soundService';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  items: { product: Product; quantity: number }[];
  onOpenNobabPay: (shortfall?: number) => void;
  onOpenAuth: () => void;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  items,
  onOpenNobabPay,
  onOpenAuth,
  onOrderSuccess,
}) => {
  const settings = storageService.getSettings();

  const [deliveryZone, setDeliveryZone] = useState<'inside_dhaka' | 'outside_dhaka'>('inside_dhaka');
  const [customerName, setCustomerName] = useState(currentUser?.name || '');
  const [customerPhone, setCustomerPhone] = useState(currentUser?.phone || '01739376516');
  const [alternativePhone, setAlternativePhone] = useState('');
  const [district, setDistrict] = useState('ঢাকা (Dhaka)');
  const [thana, setThana] = useState('মিরপুর / বনানী (Mirpur / Banani)');
  const [fullAddress, setFullAddress] = useState('বাড়ি নং ১২, রোড নং ৫, ব্লক বি');
  const [orderNotes, setOrderNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);

  if (!isOpen) return null;

  const deliveryCharge =
    deliveryZone === 'inside_dhaka'
      ? settings.deliveryChargeInsideDhaka
      : settings.deliveryChargeOutsideDhaka;

  const itemsSubtotal = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const totalOrderValue = itemsSubtotal + deliveryCharge;

  const walletBalance = currentUser?.walletBalance || 0;
  const isBalanceSufficient = walletBalance >= deliveryCharge;
  const shortfall = Math.max(0, deliveryCharge - walletBalance);

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (!customerName || !customerPhone || !fullAddress || !district || !thana) {
      setErrorMessage('অনুগ্রহ করে ডেলিভারি ফর্মের সকল প্রয়োজনীয় তথ্য পূরণ করুন');
      return;
    }

    if (!isBalanceSufficient) {
      setErrorMessage(
        `আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই। ডেলিভারি চার্জ ৳${deliveryCharge} অগ্রিম পরিশোধ করতে হবে। ওয়ালেটে আরও ৳${shortfall} যোগ করুন।`
      );
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      try {
        const result = storageService.placeOrderWithPrepaidDelivery({
          customerName,
          customerPhone,
          alternativePhone,
          district,
          thana,
          fullAddress,
          deliveryZone,
          orderNotes,
          items,
        });

        setIsSubmitting(false);

        if (!result.success || !result.order) {
          setErrorMessage(result.error || 'অর্ডার করতে সমস্যা হয়েছে');
          return;
        }

        // Order placed successfully!
        soundService.playSuccessChime();
        try {
          confetti({
            particleCount: 100,
            spread: 80,
            origin: { y: 0.5 },
          });
        } catch {
          // ignore
        }

        setPlacedOrder(result.order);
        onOrderSuccess(result.order);
      } catch (err: unknown) {
        setIsSubmitting(false);
        setErrorMessage(err instanceof Error ? err.message : 'অর্ডার প্রক্রিয়াকরণে ত্রুটি হয়েছে');
      }
    }, 600);
  };

  // SUCCESS SCREEN
  if (placedOrder) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
        <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl p-6 text-center space-y-4">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div>
            <span className="text-xs px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-full">
              অর্ডার সফল হয়েছে! (Order Confirmed)
            </span>
            <h2 className="text-2xl font-bold text-slate-800 mt-2">ধন্যবাদ, আপনার অর্ডার গৃহীত হয়েছে</h2>
            <p className="text-xs text-slate-500 mt-1 font-mono">
              অর্ডার ট্র্যাকিং আইডি: <span className="font-bold text-slate-800">{placedOrder.orderNumber}</span>
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 text-left space-y-2 text-xs">
            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">গ্রাহকের নাম:</span>
              <span className="font-semibold text-slate-800">{placedOrder.customerName}</span>
            </div>
            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">মোবাইল:</span>
              <span className="font-semibold text-slate-800">{placedOrder.customerPhone}</span>
            </div>
            <div className="flex justify-between border-b pb-2">
              <span className="text-slate-500">ডেলিভারি ঠিকানা:</span>
              <span className="font-semibold text-slate-800 text-right max-w-[240px]">
                {placedOrder.fullAddress}, {placedOrder.thana}, {placedOrder.district}
              </span>
            </div>
            <div className="flex justify-between border-b pb-2 text-emerald-700 bg-emerald-50/60 p-2 rounded-lg">
              <span className="font-medium">অগ্রিম ওয়ালেট থেকে কর্তিত (ডেলিভারি চার্জ):</span>
              <span className="font-bold">৳{placedOrder.deliveryCharge} (পরিশোধিত)</span>
            </div>
            <div className="flex justify-between pt-1 text-slate-900 text-sm font-bold">
              <span>ক্যাশ অন ডেলিভারিতে প্রদেয় (বাকি টাকা):</span>
              <span className="text-emerald-700 font-black">৳{placedOrder.remainingCodAmount}</span>
            </div>
          </div>

          <p className="text-[11px] text-slate-500">
            আমাদের কাস্টমার কেয়ার (০১৭৩৯৩৭৬৫১৬) থেকে আপনার সাথে শীঘ্রই যোগাযোগ করা হবে।
          </p>

          <button
            onClick={() => {
              setPlacedOrder(null);
              onClose();
            }}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm transition-colors shadow-md shadow-emerald-600/20"
          >
            ঠিক আছে / শপিং চালিয়ে যান
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 md:p-4 overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100 my-auto">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 p-4 md:p-5 text-white flex items-center justify-between">
          <div>
            <h3 className="font-bold text-lg flex items-center gap-2">
              <Package className="w-5 h-5 text-emerald-300" />
              অর্ডার কনফার্মেশন ও চেকআউট
            </h3>
            <p className="text-xs text-emerald-100">
              অগ্রিম ডেলিভারি চার্জ ওয়ালেট থেকে কর্তন + বাকি মূল্য ক্যাশ অন ডেলিভারি (COD)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 md:p-6 max-h-[80vh] overflow-y-auto">
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form onSubmit={handlePlaceOrder} className="space-y-5">
            {/* Products Preview */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3">
              <div className="text-xs font-bold text-slate-700 mb-2 flex items-center justify-between">
                <span>অর্ডারকৃত পণ্যসমূহ ({items.length})</span>
                <span className="text-slate-500">সাবটোটাল: ৳{itemsSubtotal}</span>
              </div>
              <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                {items.map((item) => (
                  <div
                    key={item.product.id}
                    className="flex items-center gap-3 bg-white p-2 rounded-lg border border-slate-100 text-xs"
                  >
                    <img
                      src={item.product.thumbnail}
                      alt={item.product.nameBn}
                      className="w-10 h-10 rounded-md object-cover"
                    />
                    <div className="grow min-w-0">
                      <p className="font-semibold text-slate-800 truncate">{item.product.nameBn}</p>
                      <p className="text-slate-500 text-[11px]">
                        ৳{item.product.price} × {item.quantity} = ৳{item.product.price * item.quantity}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Delivery Location Selection (CRITICAL) */}
            <div>
              <label className="block text-xs font-bold text-slate-800 mb-2">
                ডেলিভারি লোকেশন নির্বাচন করুন (Select Delivery Zone)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setDeliveryZone('inside_dhaka')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    deliveryZone === 'inside_dhaka'
                      ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800">ঢাকার ভিতরে</span>
                    <span className="font-bold text-xs text-emerald-600">
                      ৳{settings.deliveryChargeInsideDhaka}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">ঢাকা মেট্রোপলিটন এলাকা (২৪-৪৮ ঘণ্টা)</p>
                </button>

                <button
                  type="button"
                  onClick={() => setDeliveryZone('outside_dhaka')}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                    deliveryZone === 'outside_dhaka'
                      ? 'border-emerald-600 bg-emerald-50/50 ring-2 ring-emerald-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-slate-800">ঢাকার বাইরে</span>
                    <span className="font-bold text-xs text-emerald-600">
                      ৳{settings.deliveryChargeOutsideDhaka}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">সমগ্র বাংলাদেশ কুরিয়ার (২-৩ দিন)</p>
                </button>
              </div>
            </div>

            {/* Customer Details Form */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-600" />
                ডেলিভারি ও যোগাযোগের ঠিকানা (Delivery Form)
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    আপনার পূর্ণ নাম (Full Name) *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="যেমন: করিম আহমেদ"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    মোবাইল নম্বর (Phone Number) *
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="01739376516"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    বিকল্প মোবাইল নম্বর (Optional)
                  </label>
                  <input
                    type="tel"
                    value={alternativePhone}
                    onChange={(e) => setAlternativePhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">জেলা (District) *</label>
                  <input
                    type="text"
                    required
                    value={district}
                    onChange={(e) => setDistrict(e.target.value)}
                    placeholder="যেমন: ঢাকা / চট্টগ্রাম / সিলেট"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    থানা / উপজেলা (Thana) *
                  </label>
                  <input
                    type="text"
                    required
                    value={thana}
                    onChange={(e) => setThana(e.target.value)}
                    placeholder="যেমন: মিরপুর / ধানমন্ডি / সদর"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    পূর্ণ ঠিকানা (Full Address) *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullAddress}
                    onChange={(e) => setFullAddress(e.target.value)}
                    placeholder="বাড়ি, রোড, ফ্ল্যাট নম্বর"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  অর্ডার সংক্রান্ত বিশেষ নির্দেশিকা (Order Notes)
                </label>
                <input
                  type="text"
                  value={orderNotes}
                  onChange={(e) => setOrderNotes(e.target.value)}
                  placeholder="যেমন: বিকেল ৫টার পর ডেলিভারি দিন"
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* FINANCIAL BREAKDOWN & WALLET DEDUCTION SUMMARY */}
            <div className="bg-slate-900 text-white rounded-xl p-4 space-y-2.5 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-300">পণ্যের মোট মূল্য (Products Total):</span>
                <span className="font-semibold">৳{itemsSubtotal}</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10 text-emerald-400">
                <span className="font-medium">
                  অগ্রিম ডেলিভারি চার্জ ({deliveryZone === 'inside_dhaka' ? 'ঢাকার ভিতরে' : 'ঢাকার বাইরে'}):
                </span>
                <span className="font-bold">৳{deliveryCharge} (ওয়ালেট থেকে প্রদেয়)</span>
              </div>

              <div className="flex items-center justify-between pb-2 border-b border-white/10">
                <span className="text-slate-300 flex items-center gap-1.5">
                  <Wallet className="w-3.5 h-3.5 text-amber-400" />
                  আপনার বর্তমান ওয়ালেট ব্যালেন্স:
                </span>
                <span className="font-bold text-amber-400">৳{walletBalance}</span>
              </div>

              {/* Status of balance */}
              {!isBalanceSufficient ? (
                <div className="p-2.5 bg-red-950/80 border border-red-500/40 rounded-lg flex items-center justify-between gap-2">
                  <div className="text-[11px] text-red-200">
                    ⚠️ ডেলিভারি চার্জ পরিশোধে আরও <b>৳{shortfall}</b> প্রয়োজন!
                  </div>
                  <button
                    type="button"
                    onClick={() => onOpenNobabPay(shortfall)}
                    className="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white rounded-md font-bold text-[11px] flex items-center gap-1 shadow-xs cursor-pointer"
                  >
                    <PlusCircle className="w-3 h-3" />
                    টাকা যোগ করুন
                  </button>
                </div>
              ) : (
                <div className="p-2 bg-emerald-950/60 border border-emerald-500/30 rounded-lg text-[11px] text-emerald-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  ওয়ালেটে পর্যাপ্ত ব্যালেন্স আছে। কনফার্ম করার সাথে সাথে ৳{deliveryCharge} কর্তিত হবে।
                </div>
              )}

              <div className="pt-2 flex items-center justify-between text-base font-black border-t border-white/20">
                <span>ক্যাশ অন ডেলিভারিতে প্রদেয় (COD Due):</span>
                <span className="text-emerald-400 text-lg">৳{itemsSubtotal}</span>
              </div>
              <p className="text-[10px] text-slate-400">
                *পণ্য ডেলিভারি নেওয়ার সময় ডেলিভারি ম্যানকে শুধুমাত্র পণ্যের মূল্য ৳{itemsSubtotal} প্রদান করতে হবে।
              </p>
            </div>

            {/* ORDER SUBMIT BUTTON */}
            <div>
              <button
                type="submit"
                disabled={isSubmitting || !isBalanceSufficient}
                className={`w-full py-3.5 rounded-xl font-bold text-sm tracking-wide transition-all flex items-center justify-center gap-2 shadow-lg cursor-pointer ${
                  isBalanceSufficient
                    ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/30'
                    : 'bg-slate-300 text-slate-500 cursor-not-allowed'
                }`}
              >
                <span>ORDER NOW / অর্ডার নিশ্চিত করুন</span>
              </button>

              {!isBalanceSufficient && (
                <button
                  type="button"
                  onClick={() => onOpenNobabPay(shortfall)}
                  className="w-full mt-2 py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-amber-500/20 cursor-pointer"
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span>নোবাবপে দিয়ে ওয়ালেটে ৳{shortfall} যোগ করুন (Add Money)</span>
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

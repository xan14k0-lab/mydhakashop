import React, { useState } from 'react';
import {
  Search,
  ShoppingCart,
  Wallet,
  User as UserIcon,
  Phone,
  ShieldCheck,
  ChevronDown,
  LogOut,
  Package,
  LayoutDashboard,
  Plus,
  Globe,
  Sparkles,
  Menu,
  X,
} from 'lucide-react';
import { User, Language, Category } from '../types';
import { storageService } from '../services/storageService';

interface HeaderProps {
  currentUser: User | null;
  cartCount: number;
  currentLanguage: Language;
  categories: Category[];
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSelectCategory: (categoryId: string | null) => void;
  selectedCategory: string | null;
  onOpenCart: () => void;
  onOpenAuth: () => void;
  onOpenNobabPay: (amount?: number) => void;
  onOpenDashboard: (tab?: string) => void;
  onOpenAdmin: () => void;
  onLanguageChange: (lang: Language) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  cartCount,
  currentLanguage,
  categories,
  searchQuery,
  onSearchChange,
  onSelectCategory,
  selectedCategory,
  onOpenCart,
  onOpenAuth,
  onOpenNobabPay,
  onOpenDashboard,
  onOpenAdmin,
  onLanguageChange,
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const settings = storageService.getSettings();

  const handleLogout = () => {
    storageService.logout();
    setIsUserMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200/80 shadow-xs">
      {/* Top Banner Bar */}
      <div className="bg-slate-900 text-slate-300 text-[11px] py-1.5 px-4 hidden md:block">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-emerald-400 font-medium">
              <Phone className="w-3 h-3" />
              হটলাইন: {settings.businessPhone}
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300">
              ⚡ অগ্রিম শুধুমাত্র ডেলিভারি চার্জ পরিশোধ করুন, বাকি টাকা ক্যাশ অন ডেলিভারিতে দিন!
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-slate-400">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              নোবাবপে সিকিউর গেটওয়ে
            </span>
            <span className="text-slate-500">|</span>
            {/* Language Switch */}
            <button
              onClick={() => onLanguageChange(currentLanguage === 'bn' ? 'en' : 'bn')}
              className="flex items-center gap-1 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <Globe className="w-3 h-3 text-emerald-400" />
              <span>{currentLanguage === 'bn' ? 'English' : 'বাংলা'}</span>
            </button>
            <span className="text-slate-500">|</span>
            {/* Quick Admin Toggle */}
            <button
              onClick={onOpenAdmin}
              className="text-amber-400 hover:text-amber-300 font-semibold transition-colors flex items-center gap-1 cursor-pointer"
            >
              <LayoutDashboard className="w-3 h-3" />
              <span>অ্যাডমিন ড্যাশবোর্ড</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          {/* Mobile menu trigger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-slate-700 hover:bg-slate-100 rounded-lg"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          {/* Brand Logo */}
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              onSelectCategory(null);
            }}
            className="flex items-center gap-2 group shrink-0"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-600/20 group-hover:scale-105 transition-transform">
              <span className="font-extrabold text-xl tracking-tighter">M</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-black text-lg md:text-xl text-slate-900 tracking-tight leading-none">
                  MY DHAKA <span className="text-emerald-600">SHOP</span>
                </span>
              </div>
              <span className="text-[10px] text-slate-500 block leading-tight font-medium">
                {currentLanguage === 'bn' ? 'প্রিমিয়াম অনলাইন শপিং' : 'Premium E-Commerce'}
              </span>
            </div>
          </a>

          {/* Search Bar */}
          <div className="hidden sm:flex grow max-w-xl relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={
                currentLanguage === 'bn'
                  ? 'স্মার্টওয়াচ, এয়ারবাডস, পাঞ্জাবি বা পণ্য খুঁজুন...'
                  : 'Search smartwatches, gadgets, fashion...'
              }
              className="w-full pl-10 pr-4 py-2.5 bg-slate-100/80 hover:bg-slate-100 focus:bg-white border border-slate-200 rounded-full text-xs md:text-sm text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500 transition-all"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            )}
          </div>

          {/* Action Widgets */}
          <div className="flex items-center gap-2 md:gap-3 shrink-0">
            {/* Wallet Widget */}
            {currentUser && (
              <div className="flex items-center bg-emerald-50/80 hover:bg-emerald-100/70 border border-emerald-200/80 rounded-xl p-1.5 md:p-2 transition-colors">
                <div
                  onClick={() => onOpenDashboard('wallet')}
                  className="flex items-center gap-1.5 cursor-pointer pr-1.5"
                >
                  <Wallet className="w-4 h-4 text-emerald-600" />
                  <div className="text-left hidden sm:block">
                    <span className="text-[10px] text-slate-500 block leading-none">ওয়ালেট ব্যালেন্স</span>
                    <span className="text-xs font-black text-emerald-700">
                      ৳{currentUser.walletBalance}
                    </span>
                  </div>
                  <span className="text-xs font-black text-emerald-700 sm:hidden">
                    ৳{currentUser.walletBalance}
                  </span>
                </div>
                <button
                  type="button"
                  title="ওয়ালেটে টাকা যোগ করুন (Add Money)"
                  onClick={() => onOpenNobabPay(250)}
                  className="w-6 h-6 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center justify-center transition-colors shadow-xs cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {/* Shopping Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 text-slate-700 hover:text-emerald-600 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
              title="Shopping Cart"
            >
              <ShoppingCart className="w-5 h-5" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-emerald-600 text-white text-[11px] font-bold w-5 h-5 rounded-full flex items-center justify-center shadow-xs animate-in zoom-in">
                  {cartCount}
                </span>
              )}
            </button>

            {/* User Profile / Login */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center gap-2 p-1.5 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                >
                  <img
                    src={currentUser.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                    alt={currentUser.name}
                    className="w-8 h-8 rounded-full object-cover ring-2 ring-emerald-500/30"
                  />
                  <span className="hidden lg:block text-xs font-semibold text-slate-800 max-w-[100px] truncate">
                    {currentUser.name.split(' ')[0]}
                  </span>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-100 py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs font-bold text-slate-800 truncate">{currentUser.name}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <div className="mt-1.5 flex items-center justify-between text-[11px] bg-slate-50 p-1.5 rounded-lg">
                        <span className="text-slate-600">ব্যালেন্স:</span>
                        <span className="font-bold text-emerald-600">৳{currentUser.walletBalance}</span>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        onOpenDashboard('profile');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2 transition-colors"
                    >
                      <UserIcon className="w-3.5 h-3.5" />
                      <span>আমার প্রোফাইল (Profile)</span>
                    </button>

                    <button
                      onClick={() => {
                        onOpenDashboard('orders');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2 transition-colors"
                    >
                      <Package className="w-3.5 h-3.5" />
                      <span>আমার অর্ডারসমূহ (Orders)</span>
                    </button>

                    <button
                      onClick={() => {
                        onOpenDashboard('wallet');
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-slate-700 hover:bg-emerald-50 hover:text-emerald-700 flex items-center gap-2 transition-colors"
                    >
                      <Wallet className="w-3.5 h-3.5" />
                      <span>ওয়ালেট ও লেনদেন (Wallet)</span>
                    </button>

                    <div className="my-1 border-t border-slate-100"></div>

                    <button
                      onClick={() => {
                        onOpenAdmin();
                        setIsUserMenuOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-xs text-purple-700 hover:bg-purple-50 flex items-center gap-2 font-medium transition-colors"
                    >
                      <LayoutDashboard className="w-3.5 h-3.5" />
                      <span>অ্যাডমিন প্যানেল</span>
                    </button>

                    <button
                      onClick={handleLogout}
                      className="w-full px-4 py-2 text-left text-xs text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      <span>লগআউট করুন</span>
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 py-2 px-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
              >
                <UserIcon className="w-3.5 h-3.5" />
                <span>লগইন / গুগল সাইন ইন</span>
              </button>
            )}
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-2.5 sm:hidden relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="পণ্য খুঁজুন..."
            className="w-full pl-9 pr-4 py-2 bg-slate-100 border border-slate-200 rounded-full text-xs text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Categories Bar */}
      <div className="border-t border-slate-100 bg-slate-50/70 overflow-x-auto scrollbar-none">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-2 py-2 text-xs">
          <button
            onClick={() => onSelectCategory(null)}
            className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === null
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
            }`}
          >
            {currentLanguage === 'bn' ? 'সব পণ্য' : 'All Products'}
          </button>

          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors cursor-pointer ${
                selectedCategory === cat.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
              }`}
            >
              {currentLanguage === 'bn' ? cat.nameBn : cat.nameEn}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};

import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight, ShieldCheck } from 'lucide-react';
import { Banner, Language } from '../types';

interface BannerSliderProps {
  banners: Banner[];
  currentLanguage: Language;
  onCtaClick: (link: string) => void;
}

export const BannerSlider: React.FC<BannerSliderProps> = ({
  banners,
  currentLanguage,
  onCtaClick,
}) => {
  const activeBanners = banners.filter((b) => b.isActive);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (activeBanners.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [activeBanners.length]);

  if (activeBanners.length === 0) return null;

  const current = activeBanners[currentIndex] || activeBanners[0];

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? activeBanners.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % activeBanners.length);
  };

  return (
    <div className="relative max-w-7xl mx-auto px-4 pt-4 pb-2">
      <div className="relative rounded-2xl md:rounded-3xl overflow-hidden shadow-lg h-[260px] sm:h-[320px] md:h-[400px] bg-slate-900">
        {/* Background image with overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center transition-all duration-700 transform scale-105"
          style={{ backgroundImage: `url(${current.image})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/90 via-slate-900/75 to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 h-full flex flex-col justify-center px-6 sm:px-10 md:px-16 max-w-2xl text-white">
          {(current.badgeBn || current.badgeEn) && (
            <span className="inline-flex items-center gap-1.5 self-start px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 backdrop-blur-xs mb-2.5">
              {currentLanguage === 'bn' ? current.badgeBn : current.badgeEn}
            </span>
          )}

          <h2 className="text-2xl sm:text-3xl md:text-5xl font-black tracking-tight leading-tight">
            {currentLanguage === 'bn' ? current.titleBn : current.titleEn}
          </h2>

          <p className="text-xs sm:text-sm md:text-base text-slate-300 mt-2 md:mt-3 leading-relaxed max-w-xl">
            {currentLanguage === 'bn' ? current.subtitleBn : current.subtitleEn}
          </p>

          <div className="mt-4 md:mt-6 flex flex-wrap items-center gap-3">
            <button
              onClick={() => onCtaClick(current.link)}
              className="py-2.5 md:py-3 px-5 md:px-6 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs md:text-sm transition-all shadow-lg shadow-emerald-600/30 flex items-center gap-2 cursor-pointer"
            >
              <span>{currentLanguage === 'bn' ? current.buttonTextBn : current.buttonTextEn}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-emerald-300 bg-black/40 px-3 py-2 rounded-xl backdrop-blur-xs border border-white/10">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>১০০% অরিজিনাল পণ্য ও ক্যাশ অন ডেলিভারি</span>
            </div>
          </div>
        </div>

        {/* Controls */}
        {activeBanners.length > 1 && (
          <>
            <button
              onClick={handlePrev}
              className="absolute left-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-colors z-20 cursor-pointer"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={handleNext}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-2 rounded-full bg-black/40 hover:bg-black/70 text-white backdrop-blur-xs transition-colors z-20 cursor-pointer"
            >
              <ChevronRight className="w-5 h-5" />
            </button>

            {/* Dots */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-20">
              {activeBanners.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentIndex(idx)}
                  className={`h-2 rounded-full transition-all cursor-pointer ${
                    currentIndex === idx ? 'w-6 bg-emerald-400' : 'w-2 bg-white/50 hover:bg-white'
                  }`}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

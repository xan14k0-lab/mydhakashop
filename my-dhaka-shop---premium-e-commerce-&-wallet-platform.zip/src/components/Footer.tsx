import React from 'react';
import {
  Phone,
  Mail,
  MapPin,
  ShieldCheck,
  Truck,
  RotateCcw,
  Headphones,
  ExternalLink,
  Wallet,
} from 'lucide-react';
import { storageService } from '../services/storageService';
import { Language } from '../types';

interface FooterProps {
  currentLanguage: Language;
  onOpenNobabPay: () => void;
  onSelectCategory: (categoryId: string | null) => void;
}

export const Footer: React.FC<FooterProps> = ({
  currentLanguage,
  onOpenNobabPay,
  onSelectCategory,
}) => {
  const settings = storageService.getSettings();

  return (
    <footer className="bg-slate-950 text-slate-300 pt-12 pb-24 md:pb-12 border-t border-slate-800">
      {/* Value Badges */}
      <div className="max-w-7xl mx-auto px-4 pb-10 border-b border-slate-850">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center shrink-0">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs md:text-sm text-white">দ্রুত ডেলিভারি</h4>
              <p className="text-[11px] text-slate-400">ঢাকা ২৪-৪৮ ঘণ্টা, সারা বাংলাদেশ</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 text-purple-400 flex items-center justify-center shrink-0">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs md:text-sm text-white">ডিজিটাল ওয়ালেট</h4>
              <p className="text-[11px] text-slate-400">অগ্রিম ডেলিভারি চার্জ কর্তন</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs md:text-sm text-white">ক্যাশ অন ডেলিভারি</h4>
              <p className="text-[11px] text-slate-400">পণ্য হাতে পেয়ে মূল্য পরিশোধ</p>
            </div>
          </div>

          <div className="flex items-center gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-xs md:text-sm text-white">কাস্টমার সাপোর্ট</h4>
              <p className="text-[11px] text-slate-400">{settings.businessPhone} (সকাল ৯ - রাত ১০)</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 py-10 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 text-xs">
        {/* Brand Info */}
        <div className="space-y-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center text-white font-extrabold text-base">
              M
            </div>
            <span className="font-black text-lg text-white tracking-tight">MY DHAKA SHOP</span>
          </div>
          <p className="text-slate-400 leading-relaxed">
            বাংলাদেশের বিশ্বস্ত মাল্টি-প্রোডাক্ট ই-কমার্স প্ল্যাটফর্ম। উচ্চমানের গ্যাজেটস, লাইফস্টাইল ও অর্গানিক পণ্যের নির্ভরযোগ্য ঠিকানা।
          </p>
          <div className="pt-2 text-slate-400 space-y-1">
            <div className="flex items-center gap-2">
              <Phone className="w-3.5 h-3.5 text-emerald-400" />
              <span>{settings.businessPhone}</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-3.5 h-3.5 text-emerald-400" />
              <span>{settings.businessEmail}</span>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5 text-emerald-400" />
              <span>{settings.businessAddress}</span>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="space-y-3">
          <h4 className="font-bold text-sm text-white">গুরুত্বপূর্ণ লিঙ্ক</h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <a
                href="#shop"
                onClick={(e) => {
                  e.preventDefault();
                  onSelectCategory(null);
                }}
                className="hover:text-emerald-400 transition-colors"
              >
                সকল পণ্য ও অফার
              </a>
            </li>
            <li>
              <button
                onClick={onOpenNobabPay}
                className="hover:text-emerald-400 transition-colors text-left"
              >
                ওয়ালেটে টাকা যোগ (NobabPay)
              </button>
            </li>
            <li>
              <a href="#about" className="hover:text-emerald-400 transition-colors">
                আমাদের সম্পর্কে (About Us)
              </a>
            </li>
            <li>
              <a href="#contact" className="hover:text-emerald-400 transition-colors">
                যোগাযোগ ও সাপোর্ট
              </a>
            </li>
          </ul>
        </div>

        {/* Policies */}
        <div className="space-y-3">
          <h4 className="font-bold text-sm text-white">পলিসি ও শর্তাবলী</h4>
          <ul className="space-y-2 text-slate-400">
            <li>
              <span className="hover:text-emerald-400 transition-colors cursor-pointer">
                প্রিপেইড ডেলিভারি ও সিওডি পলিসি
              </span>
            </li>
            <li>
              <span className="hover:text-emerald-400 transition-colors cursor-pointer">
                রিটার্ন ও রিফান্ড নীতি (Return Policy)
              </span>
            </li>
            <li>
              <span className="hover:text-emerald-400 transition-colors cursor-pointer">
                প্রাইভেসি পলিসি (Privacy Policy)
              </span>
            </li>
            <li>
              <span className="hover:text-emerald-400 transition-colors cursor-pointer">
                শর্তাবলী ও নিয়ম (Terms & Conditions)
              </span>
            </li>
          </ul>
        </div>

        {/* Payment Channels */}
        <div className="space-y-3">
          <h4 className="font-bold text-sm text-white">সিকিউর পেমেন্ট পার্টনার</h4>
          <p className="text-slate-400 text-[11px] leading-relaxed">
            নোবাবপে (NobabPay) গেটওয়ের মাধ্যমে ১০০% নিরাপদ ও এনক্রিপ্টেড পেমেন্ট
          </p>
          <div className="flex flex-wrap gap-2 pt-1">
            <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-bold text-pink-400">
              bKash
            </span>
            <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-bold text-orange-400">
              Nagad
            </span>
            <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-bold text-purple-400">
              Rocket
            </span>
            <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-bold text-amber-400">
              Upay
            </span>
            <span className="px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] font-bold text-blue-400">
              Visa/Master
            </span>
          </div>
          <div className="pt-2 text-[11px] text-slate-500 font-mono">
            ডোমেইন: {settings.websiteDomain}
          </div>
        </div>
      </div>

      {/* Bottom Copyright */}
      <div className="max-w-7xl mx-auto px-4 pt-6 border-t border-slate-900 text-center text-[11px] text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <p>© {new Date().getFullYear()} My Dhaka Shop. সর্বস্বত্ব সংরক্ষিত।</p>
        <p className="text-slate-400">
          Built for Bangladesh • Laravel Production & cPanel Shared Hosting Compatible
        </p>
      </div>
    </footer>
  );
};

import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, ArrowRight, Loader2, CreditCard, AlertCircle, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';
import { storageService } from '../services/storageService';
import { User } from '../types';

interface NobabPayModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  defaultAmount?: number;
  onSuccess?: (newBalance: number) => void;
}

type PaymentChannel = 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Card';

export const NobabPayModal: React.FC<NobabPayModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  defaultAmount = 250,
  onSuccess,
}) => {
  const [amount, setAmount] = useState<number>(defaultAmount);
  const [selectedChannel, setSelectedChannel] = useState<PaymentChannel>('bKash');
  const [step, setStep] = useState<'amount' | 'details' | 'otp' | 'pin' | 'verifying' | 'success'>('amount');
  const [accountNumber, setAccountNumber] = useState('01739376516');
  const [otp, setOtp] = useState('884920');
  const [pin, setPin] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [txnRef, setTxnRef] = useState('');

  if (!isOpen) return null;

  const settings = storageService.getSettings();

  const handleStartPayment = () => {
    if (amount < 10) {
      setErrorMessage('সর্বনিম্ন ১০ টাকা যোগ করা যাবে');
      return;
    }
    setErrorMessage('');
    const ref = `NP-TXN-${Date.now().toString().slice(-6)}`;
    setTxnRef(ref);
    setStep('details');
  };

  const handleConfirmDetails = () => {
    if (!accountNumber || accountNumber.length < 11) {
      setErrorMessage('সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন');
      return;
    }
    setErrorMessage('');
    setStep('otp');
  };

  const handleVerifyOtp = () => {
    if (!otp || otp.length < 4) {
      setErrorMessage('সঠিক ওটিপি কোড প্রদান করুন');
      return;
    }
    setErrorMessage('');
    setStep('pin');
  };

  const handleProcessFinalPayment = () => {
    if (!pin || pin.length < 4) {
      setErrorMessage('সঠিক ৪-৫ ডিজিটের গোপন পিন দিন');
      return;
    }

    setErrorMessage('');
    setStep('verifying');

    // Simulate real server-to-server verification with NobabPay Brand Key
    setTimeout(() => {
      try {
        if (!currentUser) throw new Error('ইউজার লগইন করা নেই');

        const result = storageService.topUpWalletViaNobabPay({
          userId: currentUser.id,
          amount,
          paymentChannel: selectedChannel,
          senderNumber: accountNumber,
          gatewayTxnId: `NP_${selectedChannel.toUpperCase()}_${Date.now().toString().slice(-6)}`,
        });

        // Trigger confetti celebration
        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 },
          });
        } catch {
          // ignore
        }

        setStep('success');

        setTimeout(() => {
          if (onSuccess) onSuccess(result.newBalance);
        }, 1200);
      } catch (err: unknown) {
        setErrorMessage(err instanceof Error ? err.message : 'পেমেন্ট ব্যর্থ হয়েছে');
        setStep('details');
      }
    }, 1500);
  };

  const handleReset = () => {
    setStep('amount');
    setPin('');
    setErrorMessage('');
  };

  const quickAmounts = [100, 250, 500, 1000, 2000];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-100">
        {/* NobabPay Branded Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-bold text-white text-base shadow-sm">
                NP
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="font-bold text-base tracking-wide">NobabPay</h3>
                  <span className="text-[10px] px-1.5 py-0.5 bg-emerald-500/20 text-emerald-400 font-semibold rounded-md border border-emerald-500/30">
                    GATEWAY
                  </span>
                </div>
                <p className="text-[11px] text-slate-300">
                  {settings.websiteName} • সিকিউর ওয়ালেট পেমেন্ট
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Verification Brand Key tag */}
          <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Brand Key: {settings.nobabPayBrandKey}
            </span>
            <span className="text-emerald-400 font-medium">100% Encrypted</span>
          </div>
        </div>

        <div className="p-6">
          {errorMessage && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* STEP 1: Select Amount */}
          {step === 'amount' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  কত টাকা ওয়ালেটে যোগ করতে চান? (Top-up Amount)
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-3 text-lg font-bold text-slate-400">৳</span>
                  <input
                    type="number"
                    min="10"
                    max="50000"
                    value={amount || ''}
                    onChange={(e) => setAmount(Number(e.target.value))}
                    className="w-full pl-9 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl font-bold text-lg text-slate-800 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    placeholder="টাকার পরিমাণ লিখুন"
                  />
                </div>
              </div>

              {/* Quick Amount Pills */}
              <div className="flex flex-wrap gap-2">
                {quickAmounts.map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => setAmount(amt)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      amount === amt
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    +৳{amt}
                  </button>
                ))}
              </div>

              {/* Payment Channel Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-2">
                  পেমেন্ট মেথড নির্বাচন করুন (Select Method)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'bKash', name: 'বিকাশ', color: 'border-pink-300 hover:border-pink-500 bg-pink-50/50', badge: 'bKash' },
                    { id: 'Nagad', name: 'নগদ', color: 'border-orange-300 hover:border-orange-500 bg-orange-50/50', badge: 'Nagad' },
                    { id: 'Rocket', name: 'রকেট', color: 'border-purple-300 hover:border-purple-500 bg-purple-50/50', badge: 'Rocket' },
                    { id: 'Upay', name: 'উপায়', color: 'border-amber-300 hover:border-amber-500 bg-amber-50/50', badge: 'Upay' },
                    { id: 'Card', name: 'কার্ড', color: 'border-blue-300 hover:border-blue-500 bg-blue-50/50', badge: 'Visa/Master' },
                  ].map((ch) => (
                    <button
                      key={ch.id}
                      type="button"
                      onClick={() => setSelectedChannel(ch.id as PaymentChannel)}
                      className={`p-2.5 rounded-xl border text-center transition-all cursor-pointer ${
                        selectedChannel === ch.id
                          ? 'border-emerald-600 ring-2 ring-emerald-500/20 bg-emerald-50/30'
                          : ch.color
                      }`}
                    >
                      <span className="block text-xs font-bold text-slate-800">{ch.name}</span>
                      <span className="text-[10px] text-slate-500">{ch.badge}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs">
                💡 অগ্রিম ডেলিভারি চার্জ পরিশোধের জন্য ওয়ালেটে অন্তত ৳{settings.deliveryChargeInsideDhaka} থেকে ৳{settings.deliveryChargeOutsideDhaka} রাখা প্রয়োজন।
              </div>

              <button
                type="button"
                onClick={handleStartPayment}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-sm transition-colors shadow-md shadow-emerald-600/20 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>নোবাবপে দিয়ে এগিয়ে যান (Pay ৳{amount})</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* STEP 2: Mobile Number Input */}
          {step === 'details' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                <span className="text-xs text-slate-500">পেমেন্ট মেথড:</span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                  {selectedChannel} (৳{amount})
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  আপনার {selectedChannel} অ্যাকাউন্ট নম্বর দিন:
                </label>
                <input
                  type="tel"
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                  placeholder="01XXXXXXXXX"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-sm focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  নম্বরে একটি সিকিউর ওটিপি পাঠানো হবে।
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={handleReset}
                  className="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-medium text-slate-600"
                >
                  ফিরে যান
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDetails}
                  className="grow py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-sm"
                >
                  ওটিপি পাঠান (Send OTP)
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: OTP Verification */}
          {step === 'otp' && (
            <div className="space-y-4">
              <div className="text-center py-2">
                <p className="text-xs text-slate-600">
                  {accountNumber} নম্বরে পাঠানো ৬-সংখ্যার ওটিপি কোডটি লিখুন:
                </p>
                <span className="inline-block mt-1 text-[11px] px-2 py-0.5 bg-amber-50 text-amber-700 border border-amber-200 rounded-md font-mono">
                  ডেমো ওটিপি: 884920
                </span>
              </div>

              <div>
                <input
                  type="text"
                  maxLength={6}
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  placeholder="884920"
                  className="w-full text-center tracking-widest font-mono text-xl py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('details')}
                  className="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-medium text-slate-600"
                >
                  নম্বর পরিবর্তন
                </button>
                <button
                  type="button"
                  onClick={handleVerifyOtp}
                  className="grow py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-sm"
                >
                  ওটিপি যাচাই করুন (Verify OTP)
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: PIN Confirmation */}
          {step === 'pin' && (
            <div className="space-y-4">
              <div className="text-center py-1">
                <p className="text-xs text-slate-600 font-medium">
                  {selectedChannel} অ্যাকাউন্টের পিন দিয়ে ৳{amount} পেমেন্ট নিশ্চিত করুন:
                </p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  (পরীক্ষামূলক পিন যেমন: 12345 বা যেকোনো পিন দিন)
                </p>
              </div>

              <div>
                <input
                  type="password"
                  maxLength={5}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="•••••"
                  className="w-full text-center tracking-widest text-xl py-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setStep('otp')}
                  className="py-2.5 px-4 border border-slate-200 hover:bg-slate-50 rounded-xl text-xs font-medium text-slate-600"
                >
                  পেছনে যান
                </button>
                <button
                  type="button"
                  onClick={handleProcessFinalPayment}
                  className="grow py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs transition-colors shadow-md shadow-emerald-600/20"
                >
                  পেমেন্ট সম্পন্ন করুন (Confirm ৳{amount})
                </button>
              </div>
            </div>
          )}

          {/* STEP 5: Verifying Server-Side */}
          {step === 'verifying' && (
            <div className="py-8 text-center space-y-3">
              <Loader2 className="w-10 h-10 text-emerald-600 animate-spin mx-auto" />
              <h4 className="font-bold text-slate-800 text-sm">
                NobabPay সার্ভারে পেমেন্ট যাচাই করা হচ্ছে...
              </h4>
              <p className="text-xs text-slate-500">
                অনুগ্রহ করে অপেক্ষা করুন। ট্রানজেকশন রেফারেন্স: <span className="font-mono">{txnRef}</span>
              </p>
            </div>
          )}

          {/* STEP 6: Success */}
          {step === 'success' && (
            <div className="py-6 text-center space-y-3">
              <div className="w-14 h-14 bg-emerald-100 rounded-full flex items-center justify-center mx-auto text-emerald-600">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="font-bold text-slate-800 text-lg">
                পেমেন্ট সফল হয়েছে!
              </h4>
              <p className="text-xs text-slate-600">
                আপনার ওয়ালেটে <span className="font-bold text-emerald-600">৳{amount}</span> সফলভাবে যোগ করা হয়েছে।
              </p>
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left text-[11px] space-y-1 font-mono text-slate-600">
                <div>গেটওয়ে: NobabPay Verified</div>
                <div>চ্যানেল: {selectedChannel}</div>
                <div>রেফারেন্স: {txnRef}</div>
              </div>
              <button
                type="button"
                onClick={onClose}
                className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-xl text-xs"
              >
                সম্পন্ন (Done)
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Home, ShoppingBag, Package, Wallet, User as UserIcon } from 'lucide-react';
import { Language } from '../types';

interface MobileBottomNavProps {
  currentTab: string;
  onSelectTab: (tab: 'home' | 'shop' | 'orders' | 'wallet' | 'profile') => void;
  cartCount: number;
  currentLanguage: Language;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  currentTab,
  onSelectTab,
  cartCount,
  currentLanguage,
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-2 flex items-center justify-around shadow-lg">
      <button
        onClick={() => onSelectTab('home')}
        className={`flex flex-col items-center gap-1 p-1 transition-colors ${
          currentTab === 'home' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px]">{currentLanguage === 'bn' ? 'হোম' : 'Home'}</span>
      </button>

      <button
        onClick={() => onSelectTab('shop')}
        className={`flex flex-col items-center gap-1 p-1 transition-colors ${
          currentTab === 'shop' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <ShoppingBag className="w-5 h-5" />
        <span className="text-[10px]">{currentLanguage === 'bn' ? 'শপ' : 'Shop'}</span>
      </button>

      <button
        onClick={() => onSelectTab('orders')}
        className={`flex flex-col items-center gap-1 p-1 transition-colors ${
          currentTab === 'orders' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Package className="w-5 h-5" />
        <span className="text-[10px]">{currentLanguage === 'bn' ? 'অর্ডার' : 'Orders'}</span>
      </button>

      <button
        onClick={() => onSelectTab('wallet')}
        className={`flex flex-col items-center gap-1 p-1 transition-colors ${
          currentTab === 'wallet' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <Wallet className="w-5 h-5" />
        <span className="text-[10px]">{currentLanguage === 'bn' ? 'ওয়ালেট' : 'Wallet'}</span>
      </button>

      <button
        onClick={() => onSelectTab('profile')}
        className={`flex flex-col items-center gap-1 p-1 transition-colors relative ${
          currentTab === 'profile' ? 'text-emerald-600 font-bold' : 'text-slate-500 hover:text-slate-800'
        }`}
      >
        <UserIcon className="w-5 h-5" />
        <span className="text-[10px]">{currentLanguage === 'bn' ? 'প্রোফাইল' : 'Profile'}</span>
        {cartCount > 0 && (
          <span className="absolute top-0 right-1 w-2 h-2 bg-emerald-600 rounded-full animate-ping"></span>
        )}
      </button>
    </div>
  );
};

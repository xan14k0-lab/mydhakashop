import React, { useState } from 'react';
import { X, Star, ShoppingCart, Truck, ShieldCheck, Check, ArrowRight, Package } from 'lucide-react';
import { Product, Language } from '../types';
import { storageService } from '../services/storageService';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  currentLanguage: Language;
  onAddToCart: (product: Product, quantity: number) => void;
  onQuickOrder: (product: Product, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  currentLanguage,
  onAddToCart,
  onQuickOrder,
}) => {
  const [selectedImage, setSelectedImage] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [addedMessage, setAddedMessage] = useState(false);

  if (!isOpen || !product) return null;

  const currentImg = selectedImage || product.thumbnail;
  const settings = storageService.getSettings();

  const handleAddToCart = () => {
    onAddToCart(product, quantity);
    setAddedMessage(true);
    setTimeout(() => setAddedMessage(false), 2000);
  };

  const handleQuickOrder = () => {
    onQuickOrder(product, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-3 md:p-4 overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-100 my-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 max-h-[85vh] overflow-y-auto">
          {/* Gallery Column */}
          <div className="p-6 bg-slate-50 flex flex-col justify-between">
            <div className="aspect-square rounded-2xl overflow-hidden bg-white border border-slate-200 shadow-inner flex items-center justify-center">
              <img
                src={currentImg}
                alt={product.nameBn}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Gallery thumbnails */}
            {product.images && product.images.length > 1 && (
              <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
                {product.images.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setSelectedImage(img)}
                    className={`w-14 h-14 rounded-xl border-2 overflow-hidden shrink-0 cursor-pointer transition-all ${
                      currentImg === img ? 'border-emerald-600 ring-2 ring-emerald-500/30' : 'border-slate-200 opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}

            {/* Policy highlights */}
            <div className="mt-4 pt-4 border-t border-slate-200 space-y-2 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>১০০% খাঁটি ও অরিজিনাল কোয়ালিটি গ্যারান্টি</span>
              </div>
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-emerald-600" />
                <span>ঢাকার ভিতর ৳{settings.deliveryChargeInsideDhaka}, বাইরে ৳{settings.deliveryChargeOutsideDhaka} (অগ্রিম কর্তিত)</span>
              </div>
            </div>
          </div>

          {/* Product Info Column */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              {/* Category & Rating */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                  ইন-স্টক ({product.stock} টি অবশিষ্ট)
                </span>
                <div className="flex items-center gap-1 text-xs font-bold text-slate-700">
                  <Star className="w-4 h-4 text-amber-400 fill-current" />
                  <span>{product.rating}</span>
                  <span className="text-slate-400 font-normal">({product.reviewCount} রিভিউ)</span>
                </div>
              </div>

              {/* Title */}
              <h2 className="text-lg md:text-xl font-black text-slate-900 leading-snug">
                {currentLanguage === 'bn' ? product.nameBn : product.nameEn}
              </h2>

              {/* Price & Discount */}
              <div className="mt-3 flex items-baseline gap-3">
                <span className="text-2xl md:text-3xl font-black text-emerald-600">
                  ৳{product.price.toLocaleString()}
                </span>
                {product.originalPrice > product.price && (
                  <>
                    <span className="text-sm text-slate-400 line-through">
                      ৳{product.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-md border border-red-200">
                      -{product.discountPercentage}% ছাড়
                    </span>
                  </>
                )}
              </div>

              {/* Description */}
              <div className="mt-4 text-xs md:text-sm text-slate-600 leading-relaxed">
                <p>{currentLanguage === 'bn' ? product.descriptionBn : product.descriptionEn}</p>
              </div>

              {/* Specifications */}
              {product.specifications && Object.keys(product.specifications).length > 0 && (
                <div className="mt-4 pt-4 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-800 mb-2">স্পেসিফিকেশন:</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {Object.entries(product.specifications).map(([key, value]) => (
                      <div key={key} className="bg-slate-50 p-2 rounded-lg">
                        <span className="text-slate-400 block text-[10px]">{key}</span>
                        <span className="font-semibold text-slate-800">{value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Important Prepaid delivery charge note */}
              <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-xl text-[11px] text-amber-900 leading-relaxed">
                <span className="font-bold">💡 পেমেন্ট নিয়ম:</span> অর্ডার কনফার্ম করতে শুধুমাত্র ডেলিভারি চার্জ (৳{settings.deliveryChargeInsideDhaka}/৳{settings.deliveryChargeOutsideDhaka}) আপনার ডিজিটাল ওয়ালেট থেকে অগ্রিম কর্তিত হবে। পণ্যের বাকি মূল্য <b>৳{product.price * quantity}</b> ডেলিভারির সময় কুরিয়ারম্যানকে ক্যাশ পরিশোধ করবেন।
              </div>
            </div>

            {/* Actions */}
            <div className="mt-6 pt-4 border-t border-slate-100 space-y-3">
              {/* Quantity Selector */}
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-700">পরিমাণ (Quantity):</span>
                <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-slate-50">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                  >
                    -
                  </button>
                  <span className="px-4 py-1.5 font-bold text-xs text-slate-800 bg-white min-w-[36px] text-center">
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                    className="px-3 py-1.5 text-slate-600 hover:bg-slate-200 font-bold transition-colors"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  {addedMessage ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span className="text-emerald-700 font-bold">কার্টে যোগ হয়েছে</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4" />
                      <span>কার্টে যোগ করুন</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleQuickOrder}
                  className="py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors shadow-md shadow-emerald-600/20 cursor-pointer"
                >
                  <span>এখনই অর্ডার করুন</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

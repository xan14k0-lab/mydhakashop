import React, { useState } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingBag,
  Users,
  Wallet,
  Settings,
  Bell,
  Download,
  Plus,
  Trash2,
  Edit2,
  CheckCircle,
  Clock,
  Truck,
  RotateCcw,
  Search,
  Filter,
  Eye,
  Sliders,
  DollarSign,
  TrendingUp,
  ShieldAlert,
  ArrowRight,
  ExternalLink,
  Code2,
  FileCode,
  Check,
  X,
  Sparkles,
} from 'lucide-react';
import {
  Product,
  Category,
  Banner,
  Order,
  WalletTransaction,
  User,
  WebsiteSettings,
  OrderStatus,
} from '../types';
import { storageService } from '../services/storageService';
import { generateLaravelZip } from '../services/laravelZipGenerator';

interface AdminDashboardProps {
  onClose: () => void;
  currentUser: User | null;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onClose, currentUser }) => {
  const [activeTab, setActiveTab] = useState<
    | 'overview'
    | 'orders'
    | 'products'
    | 'categories'
    | 'banners'
    | 'customers'
    | 'wallets'
    | 'settings'
    | 'laravel_export'
  >('overview');

  const [products, setProducts] = useState<Product[]>(storageService.getProducts());
  const [categories, setCategories] = useState<Category[]>(storageService.getCategories());
  const [banners, setBanners] = useState<Banner[]>(storageService.getBanners());
  const [orders, setOrders] = useState<Order[]>(storageService.getOrders());
  const [transactions, setTransactions] = useState<WalletTransaction[]>(
    storageService.getWalletTransactions()
  );
  const [users, setUsers] = useState<User[]>(storageService.getUsers());
  const [settings, setSettings] = useState<WebsiteSettings>(storageService.getSettings());
  const [notifications, setNotifications] = useState(storageService.getNotifications());

  // Search & Filter States
  const [orderSearch, setOrderSearch] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');
  const [productSearch, setProductSearch] = useState('');
  const [selectedOrderForModal, setSelectedOrderForModal] = useState<Order | null>(null);

  // Modals for Create/Edit
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Partial<Product> | null>(null);
  const [isBannerModalOpen, setIsBannerModalOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Partial<Banner> | null>(null);
  const [isCategoryModalOpen, setIsCategoryModalOpen] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);

  // Manual Adjustment Modal
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(false);
  const [adjustUserId, setAdjustUserId] = useState('');
  const [adjustAmount, setAdjustAmount] = useState<number>(100);
  const [adjustType, setAdjustType] = useState<'credit' | 'debit'>('credit');
  const [adjustReason, setAdjustReason] = useState('');

  // Laravel Zip Download State
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);
  const [saveSettingsSuccess, setSaveSettingsSuccess] = useState(false);

  const refreshAll = () => {
    setProducts(storageService.getProducts());
    setCategories(storageService.getCategories());
    setBanners(storageService.getBanners());
    setOrders(storageService.getOrders());
    setTransactions(storageService.getWalletTransactions());
    setUsers(storageService.getUsers());
    setSettings(storageService.getSettings());
    setNotifications(storageService.getNotifications());
  };

  // KPIs
  const totalRevenue = orders.reduce((sum, o) => (o.status !== 'cancelled' ? sum + o.totalOrderValue : sum), 0);
  const pendingOrdersCount = orders.filter((o) => o.status === 'pending').length;
  const confirmedOrdersCount = orders.filter((o) => o.status === 'confirmed').length;
  const deliveredOrdersCount = orders.filter((o) => o.status === 'delivered').length;
  const totalWalletCredits = transactions
    .filter((t) => t.type === 'credit')
    .reduce((sum, t) => sum + t.amount, 0);
  const totalWalletBalanceInSystem = users.reduce((sum, u) => sum + u.walletBalance, 0);

  // Order status actions
  const handleUpdateOrderStatus = (orderId: string, status: OrderStatus) => {
    storageService.updateOrderStatus(orderId, status);
    refreshAll();
  };

  const handleCancelAndRefund = (orderId: string) => {
    if (confirm('আপনি কি এই অর্ডারটি বাতিল করে প্রিপেইড ডেলিভারি চার্জ কাস্টমার ওয়ালেটে রিফান্ড করতে চান?')) {
      storageService.cancelOrderAndRefundDeliveryCharge(orderId, 'অ্যাডমিন কর্তৃক বাতিল ও রিফান্ড');
      refreshAll();
    }
  };

  const handleToggleUser = (userId: string) => {
    storageService.toggleUserStatus(userId);
    refreshAll();
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingProduct) return;
    storageService.saveProduct(editingProduct);
    setIsProductModalOpen(false);
    setEditingProduct(null);
    refreshAll();
  };

  const handleDeleteProduct = (id: string) => {
    if (confirm('পণ্যটি মুছে ফেলতে নিশ্চিত?')) {
      storageService.deleteProduct(id);
      refreshAll();
    }
  };

  const handleSaveCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCategory) return;
    storageService.saveCategory(editingCategory);
    setIsCategoryModalOpen(false);
    setEditingCategory(null);
    refreshAll();
  };

  const handleDeleteCategory = (id: string) => {
    if (confirm('ক্যাটাগরিটি মুছে ফেলতে চান?')) {
      storageService.deleteCategory(id);
      refreshAll();
    }
  };

  const handleSaveBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBanner) return;
    storageService.saveBanner(editingBanner);
    setIsBannerModalOpen(false);
    setEditingBanner(null);
    refreshAll();
  };

  const handleDeleteBanner = (id: string) => {
    if (confirm('ব্যানারটি মুছে ফেলতে চান?')) {
      storageService.deleteBanner(id);
      refreshAll();
    }
  };

  const handleManualAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustUserId || adjustAmount <= 0) return;
    storageService.manualWalletAdjustment({
      userId: adjustUserId,
      amount: adjustAmount,
      type: adjustType,
      reason: adjustReason || 'অ্যাডমিন ম্যানুয়াল ব্যালেন্স সমন্বয়',
      adminName: currentUser?.name || 'Super Admin',
    });
    setIsAdjustModalOpen(false);
    setAdjustReason('');
    refreshAll();
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.updateSettings(settings);
    setSaveSettingsSuccess(true);
    setTimeout(() => setSaveSettingsSuccess(false), 2500);
    refreshAll();
  };

  const handleDownloadLaravelZip = async () => {
    try {
      setIsExporting(true);
      const zipBlob = await generateLaravelZip();
      const url = URL.createObjectURL(zipBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MyDhakaShop-Laravel-cPanel-Production-Package.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      setIsExporting(false);
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 4000);
    } catch {
      setIsExporting(false);
      alert('Error building zip');
    }
  };

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.orderNumber.toLowerCase().includes(orderSearch.toLowerCase()) ||
      order.customerPhone.includes(orderSearch) ||
      order.customerName.toLowerCase().includes(orderSearch.toLowerCase());
    const matchesStatus = orderStatusFilter === 'all' || order.status === orderStatusFilter;
    return matchesSearch && matchesStatus;
  });

  const filteredProducts = products.filter((p) =>
    p.nameBn.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.nameEn.toLowerCase().includes(productSearch.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-900 text-slate-100 flex flex-col overflow-hidden">
      {/* Top Admin Navbar */}
      <header className="bg-slate-950 border-b border-slate-800 px-4 md:px-6 py-3 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 to-indigo-500 flex items-center justify-center font-black text-white text-base shadow-sm">
            👑
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-bold text-sm md:text-base text-white">MY DHAKA SHOP • সুপার অ্যাডমিন</h2>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded-full border border-emerald-500/30">
                LIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              ম্যানেজমেন্ট ড্যাশবোর্ড, নোবাবপে ট্রানজেকশন ও অর্ডার প্রসেসিং
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 md:gap-3">
          {/* Unread Orders notification bell */}
          <div className="relative">
            <button
              onClick={() => {
                setActiveTab('orders');
                storageService.markNotificationsAsRead();
                refreshAll();
              }}
              className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition-colors cursor-pointer relative"
              title="নতুন অর্ডার নোটিফিকেশন"
            >
              <Bell className="w-4 h-4" />
              {pendingOrdersCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white font-bold text-[10px] w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {pendingOrdersCount}
                </span>
              )}
            </button>
          </div>

          {/* Download Laravel Project Button */}
          <button
            onClick={handleDownloadLaravelZip}
            disabled={isExporting}
            className="hidden sm:flex items-center gap-1.5 py-1.5 px-3 bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white rounded-xl text-xs font-bold shadow-md shadow-red-900/30 transition-all cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{isExporting ? 'জিপ তৈরি হচ্ছে...' : 'Laravel cPanel (.ZIP)'}</span>
          </button>

          {/* Switch Back to Website */}
          <button
            onClick={onClose}
            className="py-1.5 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
          >
            ওয়েবসাইটে ফিরুন
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="grow flex overflow-hidden">
        {/* Left Navigation Tabs */}
        <aside className="w-56 md:w-64 bg-slate-950 border-r border-slate-800 p-3 flex flex-col justify-between shrink-0 overflow-y-auto">
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span>ওভারভিউ ও মেট্রিক্স</span>
            </button>

            <button
              onClick={() => setActiveTab('orders')}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'orders'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <ShoppingBag className="w-4 h-4" />
                <span>অর্ডার ম্যানেজমেন্ট</span>
              </div>
              {pendingOrdersCount > 0 && (
                <span className="px-1.5 py-0.5 rounded-md text-[10px] bg-red-500 text-white font-bold">
                  {pendingOrdersCount}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('products')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'products'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>পণ্য ম্যানেজমেন্ট</span>
            </button>

            <button
              onClick={() => setActiveTab('categories')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'categories'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Sliders className="w-4 h-4" />
              <span>ক্যাটাগরি সমূহ</span>
            </button>

            <button
              onClick={() => setActiveTab('banners')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'banners'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>ব্যানার স্লাইডার</span>
            </button>

            <button
              onClick={() => setActiveTab('customers')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'customers'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>গ্রাহক তালিকা ({users.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('wallets')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'wallets'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>ওয়ালেট ও নোবাবপে লগ</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'settings'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                  : 'text-slate-400 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Settings className="w-4 h-4" />
              <span>ওয়েবসাইট সেটিংস</span>
            </button>

            <div className="pt-2 border-t border-slate-800/80"></div>

            <button
              onClick={() => setActiveTab('laravel_export')}
              className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer ${
                activeTab === 'laravel_export'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/20'
                  : 'text-rose-400 hover:bg-rose-950/40 hover:text-rose-300'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>cPanel & Laravel কোড</span>
            </button>
          </nav>

          <div className="p-3 bg-slate-900 rounded-2xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
            <span className="text-slate-300 font-bold block">সিস্টেম ইনফো:</span>
            <div>হোস্টিং: cPanel Ready</div>
            <div>ডাটাবেস: MySQL / Prepared</div>
            <div>গেটওয়ে: NobabPay Verified</div>
          </div>
        </aside>

        {/* Right Content Area */}
        <main className="grow p-4 md:p-6 overflow-y-auto bg-slate-900">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Header */}
              <div>
                <h2 className="text-xl md:text-2xl font-black text-white">ড্যাশবোর্ড সামারি ও মেট্রিক্স</h2>
                <p className="text-xs text-slate-400">মাই ঢাকা শপের রিয়েল-টাইম বিক্রয় ও ওয়ালেট ট্রানজেকশন</p>
              </div>

              {/* KPI Cards Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">মোট বিক্রয় মূল্য (Revenue)</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-emerald-400">
                      ৳{totalRevenue.toLocaleString()}
                    </span>
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">মোট অর্ডার (Orders)</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-white">{orders.length}</span>
                    <ShoppingBag className="w-4 h-4 text-purple-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-amber-400 font-medium block">অপেক্ষমাণ অর্ডার (Pending)</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-amber-400">
                      {pendingOrdersCount}
                    </span>
                    <Clock className="w-4 h-4 text-amber-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-emerald-400 font-medium block">ডেলিভারড অর্ডার (Delivered)</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-emerald-400">
                      {deliveredOrdersCount}
                    </span>
                    <CheckCircle className="w-4 h-4 text-emerald-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">মোট নোবাবপে টপ-আপ</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-indigo-400">
                      ৳{totalWalletCredits.toLocaleString()}
                    </span>
                    <Wallet className="w-4 h-4 text-indigo-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">সিস্টেম ওয়ালেট ব্যালেন্স</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-teal-400">
                      ৳{totalWalletBalanceInSystem.toLocaleString()}
                    </span>
                    <DollarSign className="w-4 h-4 text-teal-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">মোট নিবন্ধিত গ্রাহক</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-white">{users.length}</span>
                    <Users className="w-4 h-4 text-blue-400" />
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <span className="text-xs text-slate-400 font-medium block">লাইভ পণ্য (Products)</span>
                  <div className="flex items-baseline justify-between mt-1">
                    <span className="text-xl md:text-2xl font-black text-white">{products.length}</span>
                    <Package className="w-4 h-4 text-amber-400" />
                  </div>
                </div>
              </div>

              {/* Recent Orders and Recent Transactions */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {/* Recent Orders */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                    <h3 className="font-bold text-sm text-white">সাম্প্রতিক অর্ডারসমূহ</h3>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="text-xs text-purple-400 hover:text-purple-300 font-semibold"
                    >
                      সব দেখুন →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {orders.slice(0, 4).map((order) => (
                      <div
                        key={order.id}
                        className="p-2.5 bg-slate-900 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-white">#{order.orderNumber}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                              {order.status}
                            </span>
                          </div>
                          <span className="text-[11px] text-slate-400">
                            {order.customerName} ({order.customerPhone})
                          </span>
                        </div>
                        <div className="text-right">
                          <span className="font-black text-emerald-400 block">৳{order.remainingCodAmount} COD</span>
                          <span className="text-[10px] text-slate-500">অগ্রিম: ৳{order.deliveryCharge}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent NobabPay Transactions */}
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                    <h3 className="font-bold text-sm text-white">সাম্প্রতিক ওয়ালেট লেনদেন</h3>
                    <button
                      onClick={() => setActiveTab('wallets')}
                      className="text-xs text-purple-400 hover:text-purple-300 font-semibold"
                    >
                      সব দেখুন →
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    {transactions.slice(0, 4).map((t) => (
                      <div
                        key={t.id}
                        className="p-2.5 bg-slate-900 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
                      >
                        <div>
                          <p className="font-semibold text-slate-200">{t.title}</p>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {t.transactionRef} • {t.userName}
                          </span>
                        </div>
                        <span
                          className={`font-black text-sm ${
                            t.type === 'credit' || t.type === 'refund'
                              ? 'text-emerald-400'
                              : 'text-red-400'
                          }`}
                        >
                          {t.type === 'credit' || t.type === 'refund' ? '+' : '-'}৳{t.amount}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ORDERS MANAGEMENT */}
          {activeTab === 'orders' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-white">অর্ডার ম্যানেজমেন্ট ({orders.length})</h2>
                  <p className="text-xs text-slate-400">
                    অগ্রিম ওয়ালেট ডেলিভারি ফি কর্তিত ও অবশিষ্ট ক্যাশ অন ডেলিভারি
                  </p>
                </div>
              </div>

              {/* Filters */}
              <div className="flex flex-wrap items-center gap-2">
                <div className="relative grow max-w-xs">
                  <input
                    type="text"
                    value={orderSearch}
                    onChange={(e) => setOrderSearch(e.target.value)}
                    placeholder="অর্ডার নম্বর বা ফোন..."
                    className="w-full pl-8 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-purple-500"
                  />
                  <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
                </div>

                <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                  {['all', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map(
                    (st) => (
                      <button
                        key={st}
                        onClick={() => setOrderStatusFilter(st)}
                        className={`px-3 py-1.5 rounded-xl font-medium capitalize transition-colors cursor-pointer ${
                          orderStatusFilter === st
                            ? 'bg-purple-600 text-white'
                            : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-white'
                        }`}
                      >
                        {st}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Orders Table */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-900 border-b border-slate-800 text-slate-400">
                      <tr>
                        <th className="p-3">অর্ডার আইডি</th>
                        <th className="p-3">গ্রাহক</th>
                        <th className="p-3">ডেলিভারি ঠিকানা</th>
                        <th className="p-3">অগ্রিম ওয়ালেট ফি</th>
                        <th className="p-3">বাকি COD মূল্য</th>
                        <th className="p-3">স্ট্যাটাস</th>
                        <th className="p-3 text-right">অ্যাকশন</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {filteredOrders.map((order) => (
                        <tr key={order.id} className="hover:bg-slate-900/60 transition-colors">
                          <td className="p-3 font-mono font-bold text-white">#{order.orderNumber}</td>
                          <td className="p-3">
                            <span className="font-bold text-slate-200 block">{order.customerName}</span>
                            <span className="text-[11px] text-slate-400">{order.customerPhone}</span>
                          </td>
                          <td className="p-3 max-w-[200px] truncate text-slate-300">
                            {order.fullAddress}, {order.thana} ({order.deliveryZone === 'inside_dhaka' ? 'ঢাকা' : 'বাইরে'})
                          </td>
                          <td className="p-3 text-emerald-400 font-bold">
                            ৳{order.deliveryCharge} (পরিশোধিত)
                          </td>
                          <td className="p-3 font-black text-amber-400">
                            ৳{order.remainingCodAmount}
                          </td>
                          <td className="p-3">
                            <select
                              value={order.status}
                              onChange={(e) =>
                                handleUpdateOrderStatus(order.id, e.target.value as OrderStatus)
                              }
                              className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white focus:outline-hidden focus:border-purple-500"
                            >
                              <option value="pending">Pending</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="processing">Processing</option>
                              <option value="shipped">Shipped</option>
                              <option value="out_for_delivery">Out for Delivery</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled</option>
                            </select>
                          </td>
                          <td className="p-3 text-right space-x-1">
                            <button
                              onClick={() => setSelectedOrderForModal(order)}
                              className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200"
                              title="ইনভয়েস ভিউ"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            {order.status !== 'cancelled' && !order.deliveryChargeRefunded && (
                              <button
                                onClick={() => handleCancelAndRefund(order.id)}
                                className="px-2 py-1 bg-red-950 hover:bg-red-900 text-red-300 border border-red-800 rounded-lg text-[11px] font-bold"
                                title="বাতিল ও ওয়ালেটে রিফান্ড"
                              >
                                রিফান্ড ফি
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PRODUCTS MANAGEMENT */}
          {activeTab === 'products' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-white">পণ্য ম্যানেজমেন্ট ({products.length})</h2>
                  <p className="text-xs text-slate-400">পণ্য যোগ করুন, প্রাইস, ডিসকাউন্ট ও স্টক আপডেট করুন</p>
                </div>
                <button
                  onClick={() => {
                    setEditingProduct({
                      nameBn: '',
                      nameEn: '',
                      categoryId: categories[0]?.id || 'cat-gadgets',
                      price: 990,
                      originalPrice: 1500,
                      discountPercentage: 34,
                      stock: 50,
                      isFeatured: true,
                      isActive: true,
                      thumbnail: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
                      descriptionBn: '',
                      descriptionEn: '',
                    });
                    setIsProductModalOpen(true);
                  }}
                  className="py-2 px-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন পণ্য যোগ করুন</span>
                </button>
              </div>

              {/* Product search */}
              <div className="relative max-w-sm">
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="পণ্য খুঁজুন..."
                  className="w-full pl-8 pr-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white"
                />
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2.5" />
              </div>

              {/* Products Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map((p) => (
                  <div
                    key={p.id}
                    className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex gap-3">
                        <img
                          src={p.thumbnail}
                          alt={p.nameBn}
                          className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-800"
                        />
                        <div className="min-w-0">
                          <h4 className="font-bold text-xs text-white line-clamp-2">{p.nameBn}</h4>
                          <span className="text-[11px] text-purple-400 font-mono mt-1 block">
                            স্টক: {p.stock} টি
                          </span>
                        </div>
                      </div>

                      <div className="mt-3 flex items-baseline justify-between pt-2 border-t border-slate-800 text-xs">
                        <span className="font-black text-emerald-400 text-sm">৳{p.price}</span>
                        <span className="text-slate-500 line-through">৳{p.originalPrice}</span>
                        <span className="px-1.5 py-0.5 rounded-md bg-red-950 text-red-400 text-[10px] font-bold">
                          -{p.discountPercentage}%
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between">
                      <span className={`text-[10px] font-bold ${p.isActive ? 'text-emerald-400' : 'text-slate-500'}`}>
                        {p.isActive ? '● সক্রিয় (Active)' : '○ নিষ্ক্রিয়'}
                      </span>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => {
                            setEditingProduct(p);
                            setIsProductModalOpen(true);
                          }}
                          className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(p.id)}
                          className="p-1.5 bg-red-950 hover:bg-red-900 text-red-400 rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: CATEGORIES MANAGEMENT */}
          {activeTab === 'categories' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black text-white">ক্যাটাগরি সমূহ ({categories.length})</h2>
                  <p className="text-xs text-slate-400">নতুন ক্যাটাগরি তৈরি করুন বা পরিবর্তন করুন</p>
                </div>
                <button
                  onClick={() => {
                    setEditingCategory({
                      nameBn: '',
                      nameEn: '',
                      slug: '',
                      icon: 'Package',
                      image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80',
                      isActive: true,
                    });
                    setIsCategoryModalOpen(true);
                  }}
                  className="py-2 px-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন ক্যাটাগরি</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {categories.map((cat) => (
                  <div
                    key={cat.id}
                    className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between"
                  >
                    <div>
                      <h4 className="font-bold text-sm text-white">{cat.nameBn}</h4>
                      <p className="text-xs text-slate-400">{cat.nameEn}</p>
                      <span className="text-[10px] text-purple-400 mt-1 block">
                        মোট পণ্য: {cat.productCount ?? 0}
                      </span>
                    </div>
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => {
                          setEditingCategory(cat);
                          setIsCategoryModalOpen(true);
                        }}
                        className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="p-1.5 bg-red-950 hover:bg-red-900 text-red-400 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: BANNERS SLIDER MANAGEMENT */}
          {activeTab === 'banners' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-black text-white">ব্যানার স্লাইডার ({banners.length})</h2>
                  <p className="text-xs text-slate-400">হোমপেজ স্লাইডারে ব্যানার যোগ ও এডিট করুন</p>
                </div>
                <button
                  onClick={() => {
                    setEditingBanner({
                      titleBn: '',
                      titleEn: '',
                      subtitleBn: '',
                      subtitleEn: '',
                      badgeBn: '🔥 হট অফার',
                      badgeEn: '🔥 Hot Deal',
                      image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1600&q=80',
                      link: '#shop',
                      buttonTextBn: 'অর্ডার করুন',
                      buttonTextEn: 'Order Now',
                      isActive: true,
                    });
                    setIsBannerModalOpen(true);
                  }}
                  className="py-2 px-3.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>নতুন ব্যানার</span>
                </button>
              </div>

              <div className="space-y-3">
                {banners.map((b) => (
                  <div
                    key={b.id}
                    className="p-3.5 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col md:flex-row items-center gap-4"
                  >
                    <img
                      src={b.image}
                      alt=""
                      className="w-full md:w-44 h-24 rounded-xl object-cover border border-slate-800"
                    />
                    <div className="grow min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-md">
                          {b.badgeBn}
                        </span>
                        <h4 className="font-bold text-sm text-white truncate">{b.titleBn}</h4>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 line-clamp-1">{b.subtitleBn}</p>
                      <span className="text-[11px] text-purple-400 block mt-1">বাটন: {b.buttonTextBn}</span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          setEditingBanner(b);
                          setIsBannerModalOpen(true);
                        }}
                        className="py-1.5 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-xl flex items-center gap-1"
                      >
                        <Edit2 className="w-3 h-3" />
                        <span>এডিট</span>
                      </button>
                      <button
                        onClick={() => handleDeleteBanner(b.id)}
                        className="p-2 bg-red-950 hover:bg-red-900 text-red-400 rounded-xl"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 6: CUSTOMER MANAGEMENT */}
          {activeTab === 'customers' && (
            <div className="space-y-4">
              <div>
                <h2 className="text-xl font-black text-white">গ্রাহক তালিকা ({users.length})</h2>
                <p className="text-xs text-slate-400">নিবন্ধিত কাস্টমার এবং তাদের ওয়ালেট ব্যালেন্স</p>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 text-slate-400">
                    <tr>
                      <th className="p-3">গ্রাহক</th>
                      <th className="p-3">যোগাযোগ</th>
                      <th className="p-3">ওয়ালেট ব্যালেন্স</th>
                      <th className="p-3">স্ট্যাটাস</th>
                      <th className="p-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {users.map((u) => (
                      <tr key={u.id} className="hover:bg-slate-900/60">
                        <td className="p-3 flex items-center gap-2.5">
                          <img
                            src={u.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80'}
                            alt=""
                            className="w-8 h-8 rounded-full object-cover ring-1 ring-slate-700"
                          />
                          <div>
                            <span className="font-bold text-white block">{u.name}</span>
                            <span className="text-[10px] text-slate-400">{u.role}</span>
                          </div>
                        </td>
                        <td className="p-3">
                          <span className="block text-slate-300">{u.email}</span>
                          <span className="text-[11px] text-slate-500">{u.phone || '01739376516'}</span>
                        </td>
                        <td className="p-3 font-black text-emerald-400">
                          ৳{u.walletBalance}
                        </td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              u.status === 'active'
                                ? 'bg-emerald-950 text-emerald-400'
                                : 'bg-red-950 text-red-400'
                            }`}
                          >
                            {u.status}
                          </span>
                        </td>
                        <td className="p-3 text-right space-x-1">
                          <button
                            onClick={() => {
                              setAdjustUserId(u.id);
                              setIsAdjustModalOpen(true);
                            }}
                            className="px-2.5 py-1 bg-purple-900/80 hover:bg-purple-800 text-purple-200 rounded-lg text-xs font-semibold"
                          >
                            ব্যালেন্স এডজাস্ট
                          </button>
                          <button
                            onClick={() => handleToggleUser(u.id)}
                            className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs"
                          >
                            {u.status === 'active' ? 'সাসপেন্ড' : 'সক্রিয় করুন'}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 7: WALLET & NOBABPAY LOGS */}
          {activeTab === 'wallets' && (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-xl font-black text-white">ওয়ালেট ও নোবাবপে লেনদেন লগ ({transactions.length})</h2>
                  <p className="text-xs text-slate-400">
                    যাচাইকৃত নোবাবপে পেমেন্ট, অগ্রিম ডেলিভারি কর্তন ও রিফান্ড হিস্ট্রি
                  </p>
                </div>
                <button
                  onClick={() => {
                    setAdjustUserId(users[0]?.id || '');
                    setIsAdjustModalOpen(true);
                  }}
                  className="py-2 px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold"
                >
                  + ম্যানুয়াল ওয়ালেট এডজাস্ট
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 border-b border-slate-800 text-slate-400">
                    <tr>
                      <th className="p-3">ট্রানজেকশন আইডি</th>
                      <th className="p-3">গ্রাহক</th>
                      <th className="p-3">বিবরণ</th>
                      <th className="p-3">গেটওয়ে</th>
                      <th className="p-3">পরিমাণ</th>
                      <th className="p-3">পরবর্তী ব্যালেন্স</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {transactions.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-900/60">
                        <td className="p-3 font-mono font-bold text-white">{t.transactionRef}</td>
                        <td className="p-3 text-slate-300">{t.userName}</td>
                        <td className="p-3">
                          <span className="font-semibold text-slate-200 block">{t.title}</span>
                          <span className="text-[10px] text-slate-500">{t.note}</span>
                        </td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-emerald-400 font-mono text-[10px]">
                            {t.paymentGateway || 'NobabPay'}
                          </span>
                        </td>
                        <td className="p-3 font-black text-sm">
                          <span
                            className={
                              t.type === 'credit' || t.type === 'refund'
                                ? 'text-emerald-400'
                                : 'text-red-400'
                            }
                          >
                            {t.type === 'credit' || t.type === 'refund' ? '+' : '-'}৳{t.amount}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-slate-400">৳{t.balanceAfter}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 8: WEBSITE SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-4 max-w-3xl">
              <div>
                <h2 className="text-xl font-black text-white">ওয়েবসাইট সেটিংস</h2>
                <p className="text-xs text-slate-400">
                  ব্যবসার নাম, ফোন, ডেলিভারি চার্জ এবং নোবাবপে ব্রান্ড কি কনফিগারেশন
                </p>
              </div>

              {saveSettingsSuccess && (
                <div className="p-3 bg-emerald-950 border border-emerald-500 text-emerald-300 rounded-xl text-xs flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>সেটিংস সফলভাবে সংরক্ষিত হয়েছে!</span>
                </div>
              )}

              <form onSubmit={handleSaveSettings} className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">ওয়েবসাইটের নাম</label>
                    <input
                      type="text"
                      value={settings.websiteName}
                      onChange={(e) => setSettings({ ...settings, websiteName: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-hidden focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">হটলাইন / মোবাইল নম্বর</label>
                    <input
                      type="text"
                      value={settings.businessPhone}
                      onChange={(e) => setSettings({ ...settings, businessPhone: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-hidden focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">ডেলিভারি চার্জ (ঢাকার ভিতরে)</label>
                    <input
                      type="number"
                      value={settings.deliveryChargeInsideDhaka}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          deliveryChargeInsideDhaka: Number(e.target.value),
                        })
                      }
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-hidden focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">ডেলিভারি চার্জ (ঢাকার বাইরে)</label>
                    <input
                      type="number"
                      value={settings.deliveryChargeOutsideDhaka}
                      onChange={(e) =>
                        setSettings({
                          ...settings,
                          deliveryChargeOutsideDhaka: Number(e.target.value),
                        })
                      }
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white focus:outline-hidden focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">নোবাবপে Brand Key</label>
                    <input
                      type="text"
                      value={settings.nobabPayBrandKey}
                      onChange={(e) => setSettings({ ...settings, nobabPayBrandKey: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl font-mono text-emerald-400 focus:outline-hidden focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1 font-medium">Google OAuth Client ID</label>
                    <input
                      type="text"
                      value={settings.googleClientId}
                      onChange={(e) => setSettings({ ...settings, googleClientId: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl font-mono text-slate-300 focus:outline-hidden focus:border-purple-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1 font-medium">কর্ন জব কমান্ড (Cron Command)</label>
                  <input
                    type="text"
                    value={settings.cronJobCommand}
                    onChange={(e) => setSettings({ ...settings, cronJobCommand: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl font-mono text-amber-300 focus:outline-hidden focus:border-purple-500"
                  />
                </div>

                <button
                  type="submit"
                  className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold cursor-pointer transition-colors"
                >
                  সেটিংস সেভ করুন
                </button>
              </form>
            </div>
          )}

          {/* TAB 9: CPANEL & LARAVEL FULL PACKAGE EXPORTER */}
          {activeTab === 'laravel_export' && (
            <div className="space-y-5 max-w-4xl">
              <div>
                <h2 className="text-xl md:text-2xl font-black text-rose-400 flex items-center gap-2">
                  <Code2 className="w-6 h-6" />
                  cPanel Shared Hosting & Laravel 11 সোর্স কোড প্যাকেজ
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  সিপ্যানেল হোস্টিংয়ে সরাসরি আপলোড করার জন্য সম্পূর্ণ প্রস্তুত প্রোডাকশন লারাভেল কোড ও ডাটাবেস মাইগ্রেশন
                </p>
              </div>

              {exportSuccess && (
                <div className="p-4 bg-emerald-950 border border-emerald-500 text-emerald-300 rounded-2xl text-xs flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <p className="font-bold">সফলভাবে ডাউনলোড হয়েছে!</p>
                    <p className="text-[11px] text-emerald-400 mt-0.5">
                      "MyDhakaShop-Laravel-cPanel-Production-Package.zip" আপনার ডিভাইসে ডাউনলোড সম্পন্ন হয়েছে।
                    </p>
                  </div>
                </div>
              )}

              {/* Download Action Banner */}
              <div className="bg-gradient-to-r from-rose-950 via-slate-950 to-rose-950 border border-rose-800/80 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h3 className="font-bold text-white text-base">১-ক্লিকে সম্পূর্ণ লারাভেল প্রজেক্ট জিপ ডাউনলোড</h3>
                  <p className="text-xs text-rose-200/80 mt-1">
                    কন্ট্রোলার, মডেলস, নোবাবপে ক্লায়েন্ট, মাইগ্রেশন, .env এবং cPanel সেটআপ গাইড সহ
                  </p>
                </div>
                <button
                  onClick={handleDownloadLaravelZip}
                  disabled={isExporting}
                  className="py-3 px-5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-rose-900/50 flex items-center gap-2 cursor-pointer shrink-0 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>{isExporting ? 'জিপ কম্প্রেস হচ্ছে...' : 'লারাভেল জিপ প্যাকেজ ডাউনলোড (.ZIP)'}</span>
                </button>
              </div>

              {/* cPanel Guide Highlights */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <FileCode className="w-4 h-4 text-rose-400" />
                    ডাটাবেস মাইগ্রেশন ও টেবিলসমূহ
                  </h4>
                  <ul className="space-y-1 text-slate-300 text-[11px]">
                    <li>• <code className="text-purple-300">users</code> & <code className="text-purple-300">wallets</code> (ব্যালেন্স ও ভূমিকা)</li>
                    <li>• <code className="text-purple-300">wallet_transactions</code> (অপরিবর্তনীয় লেজার)</li>
                    <li>• <code className="text-purple-300">orders</code> & <code className="text-purple-300">order_items</code> (অগ্রিম ডেলিভারি + COD)</li>
                    <li>• <code className="text-purple-300">products</code> & <code className="text-purple-300">categories</code></li>
                    <li>• <code className="text-purple-300">banners</code> & <code className="text-purple-300">settings</code></li>
                  </ul>
                </div>

                <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2">
                  <h4 className="font-bold text-white flex items-center gap-2">
                    <Sliders className="w-4 h-4 text-rose-400" />
                    cPanel ক্রন জব কমান্ড
                  </h4>
                  <div className="p-2.5 bg-slate-900 rounded-xl font-mono text-[10px] text-amber-300 break-all select-all border border-slate-800">
                    * * * * * curl -s https://kbtopup.com/schedule-run &gt;/dev/null 2&gt;&amp;1
                  </div>
                  <p className="text-[10px] text-slate-400">
                    cPanel &gt; Cron Jobs মেন্যুতে প্রতি মিনিটে রান করতে এটি যোগ করুন।
                  </p>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: Order Details / Invoice */}
      {selectedOrderForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-sm">ইনভয়েস #{selectedOrderForModal.orderNumber}</h3>
              <button
                onClick={() => setSelectedOrderForModal(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="text-xs space-y-2 text-slate-300">
              <div className="flex justify-between">
                <span className="text-slate-500">গ্রাহক:</span>
                <span className="font-semibold text-white">{selectedOrderForModal.customerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">ফোন:</span>
                <span className="font-semibold text-white">{selectedOrderForModal.customerPhone}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">ঠিকানা:</span>
                <span className="font-semibold text-white text-right max-w-[240px]">
                  {selectedOrderForModal.fullAddress}, {selectedOrderForModal.thana}
                </span>
              </div>
              <div className="flex justify-between border-t border-slate-800 pt-2 text-emerald-400">
                <span>অগ্রিম ওয়ালেট থেকে কর্তন (ডেলিভারি চার্জ):</span>
                <span className="font-bold">৳{selectedOrderForModal.deliveryCharge} (Paid)</span>
              </div>
              <div className="flex justify-between text-amber-400 font-black text-sm">
                <span>ক্যাশ অন ডেলিভারিতে প্রদেয় (COD Due):</span>
                <span>৳{selectedOrderForModal.remainingCodAmount}</span>
              </div>
            </div>

            <button
              onClick={() => setSelectedOrderForModal(null)}
              className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-semibold"
            >
              বন্ধ করুন
            </button>
          </div>
        </div>
      )}

      {/* MODAL: Product Create/Edit */}
      {isProductModalOpen && editingProduct && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="relative w-full max-w-xl bg-slate-950 border border-slate-800 rounded-3xl p-6 text-white my-auto max-h-[85vh] overflow-y-auto">
            <h3 className="font-bold text-base mb-4">
              {editingProduct.id ? 'পণ্য এডিট করুন' : 'নতুন পণ্য যোগ করুন'}
            </h3>
            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">পণ্যের নাম (বাংলা)</label>
                <input
                  type="text"
                  required
                  value={editingProduct.nameBn || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, nameBn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">পণ্যের নাম (English)</label>
                <input
                  type="text"
                  required
                  value={editingProduct.nameEn || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, nameEn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">মূল্য (৳)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.price || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">আগের মূল্য (৳)</label>
                  <input
                    type="number"
                    value={editingProduct.originalPrice || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">স্টক (সংখ্যা)</label>
                  <input
                    type="number"
                    value={editingProduct.stock || 0}
                    onChange={(e) => setEditingProduct({ ...editingProduct, stock: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">ছবির লিঙ্ক (Image URL)</label>
                <input
                  type="text"
                  value={editingProduct.thumbnail || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, thumbnail: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">বিবরণ (বাংলা)</label>
                <textarea
                  rows={2}
                  value={editingProduct.descriptionBn || ''}
                  onChange={(e) => setEditingProduct({ ...editingProduct, descriptionBn: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="py-2.5 px-4 bg-slate-800 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="grow py-2.5 bg-purple-600 hover:bg-purple-500 rounded-xl font-bold"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: Manual Wallet Adjustment */}
      {isAdjustModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="relative w-full max-w-md bg-slate-950 border border-slate-800 rounded-3xl p-6 text-white space-y-4">
            <h3 className="font-bold text-base">ম্যানুয়াল ওয়ালেট ব্যালেন্স অ্যাডজাস্টমেন্ট</h3>
            <form onSubmit={handleManualAdjustment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">গ্রাহক নির্বাচন করুন:</label>
                <select
                  value={adjustUserId}
                  onChange={(e) => setAdjustUserId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} (বর্তমান ব্যালেন্স: ৳{u.walletBalance})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-400 mb-1">অ্যাকশন টাইপ:</label>
                  <select
                    value={adjustType}
                    onChange={(e) => setAdjustType(e.target.value as 'credit' | 'debit')}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  >
                    <option value="credit">যোগ করুন (Credit +)</option>
                    <option value="debit">কর্তন করুন (Debit -)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">টাকার পরিমাণ (৳):</label>
                  <input
                    type="number"
                    min="1"
                    value={adjustAmount}
                    onChange={(e) => setAdjustAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">সমন্বয়ের কারণ (Audit Reason):</label>
                <input
                  type="text"
                  required
                  placeholder="যেমন: স্পেশাল অফার বোনাস বা ভুল সংশোধন"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAdjustModalOpen(false)}
                  className="py-2.5 px-4 bg-slate-800 rounded-xl"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="grow py-2.5 bg-emerald-600 hover:bg-emerald-500 rounded-xl font-bold"
                >
                  এডজাস্টমেন্ট সম্পন্ন করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

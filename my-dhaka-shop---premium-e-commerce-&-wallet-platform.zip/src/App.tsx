import React, { useState, useEffect } from 'react';
import {
  Product,
  Category,
  Banner,
  User,
  CartItem,
  Order,
  Language,
} from './types';
import { storageService } from './services/storageService';
import { Header } from './components/Header';
import { BannerSlider } from './components/BannerSlider';
import { CategoryList } from './components/CategoryList';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { NobabPayModal } from './components/NobabPayModal';
import { AuthModal } from './components/AuthModal';
import { CustomerDashboard } from './components/CustomerDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { Footer } from './components/Footer';
import { MobileBottomNav } from './components/MobileBottomNav';
import {
  Sparkles,
  ShieldCheck,
  Truck,
  Wallet,
  ArrowRight,
  SlidersHorizontal,
  Package,
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(storageService.getCurrentUser());
  const [currentLanguage, setCurrentLanguage] = useState<Language>(storageService.getLanguage());
  const [products, setProducts] = useState<Product[]>(storageService.getProducts());
  const [categories, setCategories] = useState<Category[]>(storageService.getCategories());
  const [banners, setBanners] = useState<Banner[]>(storageService.getBanners());
  const [cart, setCart] = useState<CartItem[]>(storageService.getCart());

  // Search, Category & Sorting Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'featured' | 'price_low' | 'price_high' | 'rating'>('featured');

  // Modals & Drawers
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isNobabPayOpen, setIsNobabPayOpen] = useState(false);
  const [nobabPayDefaultAmount, setNobabPayDefaultAmount] = useState(250);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [checkoutItems, setCheckoutItems] = useState<{ product: Product; quantity: number }[]>([]);
  const [isDashboardOpen, setIsDashboardOpen] = useState(false);
  const [dashboardTab, setDashboardTab] = useState<string>('profile');
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [selectedProductForDetail, setSelectedProductForDetail] = useState<Product | null>(null);

  // Sync state on custom store events
  useEffect(() => {
    const handleStoreUpdate = () => {
      setCurrentUser(storageService.getCurrentUser());
      setCurrentLanguage(storageService.getLanguage());
      setProducts(storageService.getProducts());
      setCategories(storageService.getCategories());
      setBanners(storageService.getBanners());
      setCart(storageService.getCart());
    };

    window.addEventListener('MDS_STORE_UPDATE', handleStoreUpdate);
    return () => window.removeEventListener('MDS_STORE_UPDATE', handleStoreUpdate);
  }, []);

  const handleLanguageChange = (lang: Language) => {
    storageService.setLanguage(lang);
    setCurrentLanguage(lang);
  };

  // Cart operations
  const handleAddToCart = (product: Product, quantity = 1) => {
    storageService.addToCart(product, quantity);
  };

  const handleUpdateCartQuantity = (productId: string, quantity: number) => {
    storageService.updateCartQuantity(productId, quantity);
  };

  const handleRemoveFromCart = (productId: string) => {
    storageService.removeFromCart(productId);
  };

  // Instant Buy Now Checkout (single product)
  const handleQuickOrder = (product: Product, quantity = 1) => {
    setCheckoutItems([{ product, quantity }]);
    setIsCheckoutOpen(true);
  };

  // Proceed Checkout from Cart
  const handleProceedCheckoutFromCart = () => {
    if (cart.length === 0) return;
    setCheckoutItems(cart.map((item) => ({ product: item.product, quantity: item.quantity })));
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  // Open NobabPay modal with prefilled shortfall amount if user has insufficient wallet balance
  const handleOpenNobabPay = (amount?: number) => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setNobabPayDefaultAmount(amount && amount > 0 ? amount : 250);
    setIsNobabPayOpen(true);
  };

  // Open dashboard at specific tab
  const handleOpenDashboard = (tab = 'profile') => {
    if (!currentUser) {
      setIsAuthModalOpen(true);
      return;
    }
    setDashboardTab(tab);
    setIsDashboardOpen(true);
  };

  // Filtering products
  const filteredProducts = products.filter((p) => {
    if (!p.isActive) return false;
    if (selectedCategory && p.categoryId !== selectedCategory) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchBn = p.nameBn.toLowerCase().includes(q);
      const matchEn = p.nameEn.toLowerCase().includes(q);
      const matchDesc = p.descriptionBn.toLowerCase().includes(q);
      if (!matchBn && !matchEn && !matchDesc) return false;
    }
    return true;
  });

  // Sorting products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price_low') return a.price - b.price;
    if (sortBy === 'price_high') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0);
  });

  const featuredProducts = products.filter((p) => p.isFeatured && p.isActive);
  const settings = storageService.getSettings();
  const totalCartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans">
      {/* 1. Header */}
      <Header
        currentUser={currentUser}
        cartCount={totalCartCount}
        currentLanguage={currentLanguage}
        categories={categories}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSelectCategory={setSelectedCategory}
        selectedCategory={selectedCategory}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOpenNobabPay={handleOpenNobabPay}
        onOpenDashboard={handleOpenDashboard}
        onOpenAdmin={() => setIsAdminOpen(true)}
        onLanguageChange={handleLanguageChange}
      />

      <main className="grow">
        {/* 2. Banner Slider (shown when no specific search query) */}
        {!searchQuery && (
          <BannerSlider
            banners={banners}
            currentLanguage={currentLanguage}
            onCtaClick={(link) => {
              if (link === '#wallet') {
                handleOpenNobabPay(500);
              } else {
                const el = document.getElementById('shop');
                el?.scrollIntoView({ behavior: 'smooth' });
              }
            }}
          />
        )}

        {/* 3. Prepaid Delivery & COD Guarantee Banner */}
        <section className="max-w-7xl mx-auto px-4 py-3">
          <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-emerald-950 text-white rounded-2xl md:rounded-3xl p-4 md:p-5 shadow-sm border border-emerald-800/80 flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center shrink-0 text-emerald-300">
                <Truck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded-full border border-emerald-700/50">
                    অর্ডার পলিসি
                  </span>
                  <h3 className="font-bold text-sm md:text-base text-white">
                    অগ্রিম ডেলিভারি ফি + ক্যাশ অন ডেলিভারি (COD)
                  </h3>
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  অর্ডার করতে ডেলিভারি চার্জ (ঢাকার ভিতরে ৳{settings.deliveryChargeInsideDhaka}, বাইরে ৳{settings.deliveryChargeOutsideDhaka}) আপনার ডিজিটাল ওয়ালেট থেকে অগ্রিম কর্তিত হয়। পণ্যের বাকি মূল্য ক্যাশ অন ডেলিভারিতে দিন।
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => handleOpenNobabPay(250)}
                className="py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-colors flex items-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
              >
                <Wallet className="w-4 h-4" />
                <span>ওয়ালেটে টাকা যোগ করুন</span>
              </button>
            </div>
          </div>
        </section>

        {/* 4. Category Grid */}
        <CategoryList
          categories={categories}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          currentLanguage={currentLanguage}
        />

        {/* 5. Featured Deals Section (when no active filters) */}
        {!searchQuery && !selectedCategory && featuredProducts.length > 0 && (
          <section className="max-w-7xl mx-auto px-4 py-4">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-lg md:text-xl font-bold text-slate-900 tracking-tight">
                    {currentLanguage === 'bn' ? 'হট ডিল ও স্পেশাল অফার' : 'Hot Deals & Featured'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    সীমিত সময়ের জন্য বিশেষ ছাড়ে সেরা পণ্যসমূহ
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
              {featuredProducts.slice(0, 4).map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  currentLanguage={currentLanguage}
                  onAddToCart={handleAddToCart}
                  onQuickOrder={handleQuickOrder}
                  onViewDetails={setSelectedProductForDetail}
                />
              ))}
            </div>
          </section>
        )}

        {/* 6. Main Product Catalog Section */}
        <section id="shop" className="max-w-7xl mx-auto px-4 py-6">
          {/* Section Header & Sort Controls */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6 pb-4 border-b border-slate-200">
            <div>
              <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
                <span>
                  {selectedCategory
                    ? categories.find((c) => c.id === selectedCategory)?.nameBn || 'ক্যাটাগরি পণ্য'
                    : currentLanguage === 'bn'
                    ? 'সকল প্রিমিয়াম পণ্য'
                    : 'All Products'}
                </span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                  {sortedProducts.length} টি
                </span>
              </h2>
              {searchQuery && (
                <p className="text-xs text-slate-500 mt-1">
                  "{searchQuery}" এর জন্য অনুসন্ধান ফলাফল
                </p>
              )}
            </div>

            {/* Sorting options */}
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-slate-500 shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as 'featured' | 'price_low' | 'price_high' | 'rating')}
                className="bg-white border border-slate-200 text-slate-700 rounded-xl px-3 py-2 text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-emerald-500 cursor-pointer"
              >
                <option value="featured">ফিচার্ড ও জনপ্রিয়</option>
                <option value="price_low">মূল্য: কম থেকে বেশি</option>
                <option value="price_high">মূল্য: বেশি থেকে কম</option>
                <option value="rating">সর্বোচ্চ রেটিং</option>
              </select>
            </div>
          </div>

          {/* Product Cards Grid */}
          {sortedProducts.length === 0 ? (
            <div className="py-20 text-center bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
              <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400">
                <Package className="w-8 h-8" />
              </div>
              <h3 className="font-bold text-base text-slate-800">কোনো পণ্য খুঁজে পাওয়া যায়নি</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                অন্য কোনো শব্দ দিয়ে খুঁজুন অথবা ক্যাটাগরি ফিল্টার পরিবর্তন করুন।
              </p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedCategory(null);
                }}
                className="py-2 px-4 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-colors"
              >
                সকল পণ্য দেখুন
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-5">
              {sortedProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  currentLanguage={currentLanguage}
                  onAddToCart={handleAddToCart}
                  onQuickOrder={handleQuickOrder}
                  onViewDetails={setSelectedProductForDetail}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {/* 7. Footer */}
      <Footer
        currentLanguage={currentLanguage}
        onOpenNobabPay={() => handleOpenNobabPay(250)}
        onSelectCategory={setSelectedCategory}
      />

      {/* 8. Mobile Bottom Navigation */}
      <MobileBottomNav
        currentTab={isDashboardOpen ? 'profile' : 'home'}
        onSelectTab={(tab) => {
          if (tab === 'home') {
            setSelectedCategory(null);
            setSearchQuery('');
            window.scrollTo({ top: 0, behavior: 'smooth' });
          } else if (tab === 'shop') {
            const el = document.getElementById('shop');
            el?.scrollIntoView({ behavior: 'smooth' });
          } else if (tab === 'orders') {
            handleOpenDashboard('orders');
          } else if (tab === 'wallet') {
            handleOpenDashboard('wallet');
          } else if (tab === 'profile') {
            handleOpenDashboard('profile');
          }
        }}
        cartCount={totalCartCount}
        currentLanguage={currentLanguage}
      />

      {/* MODALS */}
      {/* 1. Auth Modal (Google & Email) */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={(user) => {
          setCurrentUser(user);
        }}
      />

      {/* 2. NobabPay Payment Modal */}
      <NobabPayModal
        isOpen={isNobabPayOpen}
        onClose={() => setIsNobabPayOpen(false)}
        currentUser={currentUser}
        defaultAmount={nobabPayDefaultAmount}
        onSuccess={(newBalance) => {
          if (currentUser) {
            setCurrentUser({ ...currentUser, walletBalance: newBalance });
          }
          setIsNobabPayOpen(false);
        }}
      />

      {/* 3. Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        currentLanguage={currentLanguage}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onProceedCheckout={handleProceedCheckoutFromCart}
      />

      {/* 4. Product Details Modal */}
      <ProductDetailModal
        product={selectedProductForDetail}
        isOpen={!!selectedProductForDetail}
        onClose={() => setSelectedProductForDetail(null)}
        currentLanguage={currentLanguage}
        onAddToCart={handleAddToCart}
        onQuickOrder={handleQuickOrder}
      />

      {/* 5. Checkout Modal (Prepaid Delivery Fee from Wallet + Remaining COD) */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        currentUser={currentUser}
        items={checkoutItems}
        onOpenNobabPay={(shortfall) => {
          handleOpenNobabPay(shortfall || 250);
        }}
        onOpenAuth={() => setIsAuthModalOpen(true)}
        onOrderSuccess={() => {
          // Sync state after successful order
          setCurrentUser(storageService.getCurrentUser());
        }}
      />

      {/* 6. Customer Dashboard Modal */}
      {isDashboardOpen && (
        <CustomerDashboard
          currentUser={currentUser}
          initialTab={dashboardTab}
          onClose={() => setIsDashboardOpen(false)}
          onOpenNobabPay={handleOpenNobabPay}
          currentLanguage={currentLanguage}
        />
      )}

      {/* 7. Advanced Admin Dashboard Modal */}
      {isAdminOpen && (
        <AdminDashboard
          onClose={() => setIsAdminOpen(false)}
          currentUser={currentUser}
        />
      )}
    </div>
  );
}

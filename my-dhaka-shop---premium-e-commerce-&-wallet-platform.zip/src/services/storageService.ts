import {
  User,
  Product,
  Category,
  Banner,
  Order,
  WalletTransaction,
  WebsiteSettings,
  CartItem,
  OrderStatus,
  AdminNotification,
  Language,
} from '../types';
import {
  initialProducts,
  initialCategories,
  initialBanners,
  initialSettings,
  initialUsers,
  initialOrders,
  initialTransactions,
} from '../data/mockData';
import { soundService } from './soundService';

const KEYS = {
  PRODUCTS: 'mds_products_v1',
  CATEGORIES: 'mds_categories_v1',
  BANNERS: 'mds_banners_v1',
  ORDERS: 'mds_orders_v1',
  TRANSACTIONS: 'mds_transactions_v1',
  USERS: 'mds_users_v1',
  CURRENT_USER: 'mds_current_user_v1',
  SETTINGS: 'mds_settings_v1',
  CART: 'mds_cart_v1',
  NOTIFICATIONS: 'mds_notifications_v1',
  LANGUAGE: 'mds_lang_v1',
};

class StorageService {
  constructor() {
    this.initDefaults();
  }

  private initDefaults() {
    if (typeof window === 'undefined') return;

    if (!localStorage.getItem(KEYS.PRODUCTS)) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(initialProducts));
    }
    if (!localStorage.getItem(KEYS.CATEGORIES)) {
      localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(initialCategories));
    }
    if (!localStorage.getItem(KEYS.BANNERS)) {
      localStorage.setItem(KEYS.BANNERS, JSON.stringify(initialBanners));
    }
    if (!localStorage.getItem(KEYS.SETTINGS)) {
      localStorage.setItem(KEYS.SETTINGS, JSON.stringify(initialSettings));
    }
    if (!localStorage.getItem(KEYS.USERS)) {
      localStorage.setItem(KEYS.USERS, JSON.stringify(initialUsers));
    }
    if (!localStorage.getItem(KEYS.ORDERS)) {
      localStorage.setItem(KEYS.ORDERS, JSON.stringify(initialOrders));
    }
    if (!localStorage.getItem(KEYS.TRANSACTIONS)) {
      localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(initialTransactions));
    }
    if (!localStorage.getItem(KEYS.CURRENT_USER)) {
      // Default to demo customer logged in so immediate shopping & wallet tests are instant!
      localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(initialUsers[0]));
    }
    if (!localStorage.getItem(KEYS.CART)) {
      localStorage.setItem(KEYS.CART, JSON.stringify([]));
    }
    if (!localStorage.getItem(KEYS.NOTIFICATIONS)) {
      localStorage.setItem(
        KEYS.NOTIFICATIONS,
        JSON.stringify([
          {
            id: 'notif-1',
            title: 'নতুন অর্ডার MDS-2026-1001',
            message: 'করিম আহমেদ ৳১,৩৫০ টাকার অর্ডার করেছেন (ডেলিভারি চার্জ ৳৭০ ওয়ালেট থেকে কর্তিত)',
            orderId: 'order-101',
            amount: 1420,
            isRead: false,
            createdAt: '2026-11-06T15:30:00Z',
          },
        ])
      );
    }
    if (!localStorage.getItem(KEYS.LANGUAGE)) {
      localStorage.setItem(KEYS.LANGUAGE, 'bn');
    }
  }

  private notify() {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('MDS_STORE_UPDATE'));
    }
  }

  // --- Language ---
  getLanguage(): Language {
    if (typeof window === 'undefined') return 'bn';
    return (localStorage.getItem(KEYS.LANGUAGE) as Language) || 'bn';
  }

  setLanguage(lang: Language) {
    localStorage.setItem(KEYS.LANGUAGE, lang);
    this.notify();
  }

  // --- Settings ---
  getSettings(): WebsiteSettings {
    const data = localStorage.getItem(KEYS.SETTINGS);
    return data ? JSON.parse(data) : initialSettings;
  }

  updateSettings(newSettings: Partial<WebsiteSettings>): WebsiteSettings {
    const current = this.getSettings();
    const updated = { ...current, ...newSettings };
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(updated));
    this.notify();
    return updated;
  }

  // --- Users & Auth ---
  getUsers(): User[] {
    const data = localStorage.getItem(KEYS.USERS);
    return data ? JSON.parse(data) : initialUsers;
  }

  getCurrentUser(): User | null {
    const data = localStorage.getItem(KEYS.CURRENT_USER);
    if (!data) return null;
    try {
      const user = JSON.parse(data);
      // Sync latest balance from users table
      const allUsers = this.getUsers();
      const match = allUsers.find((u) => u.id === user.id);
      return match || user;
    } catch {
      return null;
    }
  }

  setCurrentUser(user: User | null) {
    if (!user) {
      localStorage.removeItem(KEYS.CURRENT_USER);
    } else {
      localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(user));
    }
    this.notify();
  }

  // Google OAuth Login / Simulation
  loginWithGoogle(googleData?: { name?: string; email?: string; avatar?: string }): User {
    const name = googleData?.name || 'Karim Ahmed';
    const email = googleData?.email || 'xan14k0@gmail.com';
    const avatar =
      googleData?.avatar ||
      'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=200&q=80';

    const users = this.getUsers();
    let existing = users.find((u) => u.email.toLowerCase() === email.toLowerCase());

    if (!existing) {
      // Create new customer with bonus promotional wallet balance
      existing = {
        id: `user-${Date.now()}`,
        name,
        email,
        avatar,
        phone: '01739376516',
        role: 'customer',
        isGoogleUser: true,
        googleId: `google-${Date.now()}`,
        walletBalance: 200, // Initial promotional credit for prepaid delivery test!
        status: 'active',
        createdAt: new Date().toISOString(),
      };
      users.push(existing);
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));

      // Record welcome bonus transaction
      this.addWalletTransaction({
        userId: existing.id,
        userName: existing.name,
        type: 'credit',
        title: 'স্বাগতম বোনাস (Welcome Gift Balance)',
        amount: 200,
        status: 'completed',
        balanceAfter: 200,
        paymentGateway: 'System',
        note: 'Welcome bonus credited for testing prepaid delivery orders',
      });
    } else {
      // Update avatar if newer
      existing.avatar = avatar;
      existing.name = name;
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    }

    this.setCurrentUser(existing);
    return existing;
  }

  loginWithEmail(email: string, _password?: string, asAdmin = false): User {
    const users = this.getUsers();
    let user: User | undefined;

    if (asAdmin) {
      user = users.find((u) => u.role === 'admin');
      if (!user) {
        user = initialUsers[1];
        users.push(user);
        localStorage.setItem(KEYS.USERS, JSON.stringify(users));
      }
    } else {
      user = users.find((u) => u.email.toLowerCase() === email.toLowerCase());
      if (!user) {
        // Register user on the fly for smooth testing
        user = {
          id: `user-${Date.now()}`,
          name: email.split('@')[0],
          email,
          phone: '01739376516',
          role: 'customer',
          walletBalance: 150,
          status: 'active',
          createdAt: new Date().toISOString(),
        };
        users.push(user);
        localStorage.setItem(KEYS.USERS, JSON.stringify(users));
      }
    }

    this.setCurrentUser(user);
    return user;
  }

  logout() {
    this.setCurrentUser(null);
  }

  toggleUserStatus(userId: string): User {
    const users = this.getUsers();
    const idx = users.findIndex((u) => u.id === userId);
    if (idx === -1) throw new Error('User not found');
    users[idx].status = users[idx].status === 'active' ? 'suspended' : 'active';
    localStorage.setItem(KEYS.USERS, JSON.stringify(users));
    if (this.getCurrentUser()?.id === userId) {
      this.setCurrentUser(users[idx]);
    }
    this.notify();
    return users[idx];
  }

  // --- Cart ---
  getCart(): CartItem[] {
    const data = localStorage.getItem(KEYS.CART);
    return data ? JSON.parse(data) : [];
  }

  saveCart(items: CartItem[]) {
    localStorage.setItem(KEYS.CART, JSON.stringify(items));
    this.notify();
  }

  addToCart(product: Product, quantity = 1) {
    const cart = this.getCart();
    const existing = cart.find((item) => item.product.id === product.id);
    if (existing) {
      existing.quantity += quantity;
    } else {
      cart.push({ product, quantity });
    }
    this.saveCart(cart);
  }

  removeFromCart(productId: string) {
    const cart = this.getCart().filter((item) => item.product.id !== productId);
    this.saveCart(cart);
  }

  updateCartQuantity(productId: string, quantity: number) {
    if (quantity <= 0) {
      this.removeFromCart(productId);
      return;
    }
    const cart = this.getCart();
    const item = cart.find((i) => i.product.id === productId);
    if (item) {
      item.quantity = quantity;
      this.saveCart(cart);
    }
  }

  clearCart() {
    this.saveCart([]);
  }

  // --- Products ---
  getProducts(): Product[] {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    return data ? JSON.parse(data) : initialProducts;
  }

  saveProduct(product: Partial<Product> & { id?: string }): Product {
    const products = this.getProducts();
    if (product.id) {
      const idx = products.findIndex((p) => p.id === product.id);
      if (idx !== -1) {
        products[idx] = { ...products[idx], ...product } as Product;
        localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
        this.notify();
        return products[idx];
      }
    }
    const newProduct: Product = {
      id: `prod-${Date.now()}`,
      nameBn: product.nameBn || 'নতুন প্রোডাক্ট',
      nameEn: product.nameEn || 'New Product',
      categoryId: product.categoryId || 'cat-gadgets',
      slug: product.slug || `prod-${Date.now()}`,
      price: product.price || 999,
      originalPrice: product.originalPrice || 1499,
      discountPercentage: product.discountPercentage || 30,
      stock: product.stock !== undefined ? product.stock : 25,
      isFeatured: !!product.isFeatured,
      isActive: product.isActive !== undefined ? product.isActive : true,
      thumbnail: product.thumbnail || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80',
      images: product.images?.length ? product.images : [product.thumbnail || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=800&q=80'],
      descriptionBn: product.descriptionBn || 'উচ্চমানের প্রোডাক্ট। দ্রুত ডেলিভারি।',
      descriptionEn: product.descriptionEn || 'High quality product with fast doorstep delivery.',
      specifications: product.specifications || { 'Quality': '100% Genuine' },
      rating: 4.8,
      reviewCount: 12,
      createdAt: new Date().toISOString(),
    };
    products.unshift(newProduct);
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
    return newProduct;
  }

  deleteProduct(id: string) {
    const products = this.getProducts().filter((p) => p.id !== id);
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
  }

  // --- Categories ---
  getCategories(): Category[] {
    const data = localStorage.getItem(KEYS.CATEGORIES);
    const cats: Category[] = data ? JSON.parse(data) : initialCategories;
    // Enrich with live product count
    const products = this.getProducts();
    return cats.map((cat) => ({
      ...cat,
      productCount: products.filter((p) => p.categoryId === cat.id && p.isActive).length,
    }));
  }

  saveCategory(cat: Partial<Category> & { id?: string }): Category {
    const categories = this.getCategories();
    if (cat.id) {
      const idx = categories.findIndex((c) => c.id === cat.id);
      if (idx !== -1) {
        categories[idx] = { ...categories[idx], ...cat } as Category;
        localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
        this.notify();
        return categories[idx];
      }
    }
    const newCat: Category = {
      id: `cat-${Date.now()}`,
      nameBn: cat.nameBn || 'নতুন ক্যাটাগরি',
      nameEn: cat.nameEn || 'New Category',
      slug: cat.slug || `cat-${Date.now()}`,
      icon: cat.icon || 'Package',
      image: cat.image || 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?auto=format&fit=crop&w=600&q=80',
      isActive: true,
    };
    categories.push(newCat);
    localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
    this.notify();
    return newCat;
  }

  deleteCategory(id: string) {
    const categories = this.getCategories().filter((c) => c.id !== id);
    localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
    this.notify();
  }

  // --- Banners ---
  getBanners(): Banner[] {
    const data = localStorage.getItem(KEYS.BANNERS);
    return data ? JSON.parse(data) : initialBanners;
  }

  saveBanner(banner: Partial<Banner> & { id?: string }): Banner {
    const banners = this.getBanners();
    if (banner.id) {
      const idx = banners.findIndex((b) => b.id === banner.id);
      if (idx !== -1) {
        banners[idx] = { ...banners[idx], ...banner } as Banner;
        localStorage.setItem(KEYS.BANNERS, JSON.stringify(banners));
        this.notify();
        return banners[idx];
      }
    }
    const newBanner: Banner = {
      id: `banner-${Date.now()}`,
      titleBn: banner.titleBn || 'নতুন অফার',
      titleEn: banner.titleEn || 'New Special Deal',
      subtitleBn: banner.subtitleBn || 'অগ্রিম ডেলিভারি চার্জ পরিশোধে দ্রুত ডেলিভারি!',
      subtitleEn: banner.subtitleEn || 'Fast delivery across Bangladesh with prepaid delivery fee!',
      badgeBn: banner.badgeBn || '🔥 হট ডিল',
      badgeEn: banner.badgeEn || '🔥 Hot Deal',
      image: banner.image || 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=1600&q=80',
      link: banner.link || '#shop',
      buttonTextBn: banner.buttonTextBn || 'অর্ডার করুন',
      buttonTextEn: banner.buttonTextEn || 'Order Now',
      isActive: true,
      sortOrder: banners.length + 1,
    };
    banners.push(newBanner);
    localStorage.setItem(KEYS.BANNERS, JSON.stringify(banners));
    this.notify();
    return newBanner;
  }

  deleteBanner(id: string) {
    const banners = this.getBanners().filter((b) => b.id !== id);
    localStorage.setItem(KEYS.BANNERS, JSON.stringify(banners));
    this.notify();
  }

  // --- Orders & Prepaid Wallet Delivery Charge System ---
  getOrders(): Order[] {
    const data = localStorage.getItem(KEYS.ORDERS);
    return data ? JSON.parse(data) : initialOrders;
  }

  // CRITICAL BUSINESS RULE IMPLEMENTATION:
  // Prepaid delivery charge from wallet + remaining as Cash on Delivery (COD)
  placeOrderWithPrepaidDelivery(params: {
    customerName: string;
    customerPhone: string;
    alternativePhone?: string;
    district: string;
    thana: string;
    fullAddress: string;
    deliveryZone: 'inside_dhaka' | 'outside_dhaka';
    orderNotes?: string;
    items: { product: Product; quantity: number }[];
  }): { success: boolean; order?: Order; error?: string; requiredAmount?: number } {
    const currentUser = this.getCurrentUser();
    if (!currentUser) {
      return { success: false, error: 'অনুগ্রহ করে প্রথমে লগইন করুন (Please login to continue)' };
    }

    if (!params.items || params.items.length === 0) {
      return { success: false, error: 'কার্টে কোনো পণ্য নেই (Cart is empty)' };
    }

    const settings = this.getSettings();
    const deliveryCharge =
      params.deliveryZone === 'inside_dhaka'
        ? settings.deliveryChargeInsideDhaka
        : settings.deliveryChargeOutsideDhaka;

    // Check wallet balance
    if (currentUser.walletBalance < deliveryCharge) {
      const shortfall = deliveryCharge - currentUser.walletBalance;
      return {
        success: false,
        error: `আপনার ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই। ডেলিভারি চার্জ ৳${deliveryCharge} অগ্রিম পরিশোধ করতে হবে। আরও ৳${shortfall} যোগ করুন।`,
        requiredAmount: shortfall,
      };
    }

    // Calculate subtotal
    const orderItems = params.items.map((item) => ({
      productId: item.product.id,
      productNameBn: item.product.nameBn,
      productNameEn: item.product.nameEn,
      productThumbnail: item.product.thumbnail,
      price: item.product.price,
      quantity: item.quantity,
      subtotal: item.product.price * item.quantity,
    }));

    const itemsSubtotal = orderItems.reduce((sum, item) => sum + item.subtotal, 0);
    const orderId = `order-${Date.now()}`;
    const orderNumber = `MDS-${Date.now().toString().slice(-6)}`;

    // Deduct delivery charge from wallet
    const newWalletBalance = currentUser.walletBalance - deliveryCharge;
    this.updateUserWalletBalance(currentUser.id, newWalletBalance);

    // Record wallet deduction transaction
    this.addWalletTransaction({
      userId: currentUser.id,
      userName: currentUser.name,
      type: 'debit',
      title: `অগ্রিম ডেলিভারি চার্জ কর্তন (${orderNumber})`,
      amount: deliveryCharge,
      status: 'completed',
      balanceAfter: newWalletBalance,
      orderId,
      note: `Prepaid delivery charge deducted for Order #${orderNumber} (${params.deliveryZone === 'inside_dhaka' ? 'Inside Dhaka' : 'Outside Dhaka'})`,
    });

    const newOrder: Order = {
      id: orderId,
      orderNumber,
      userId: currentUser.id,
      customerName: params.customerName,
      customerEmail: currentUser.email,
      customerPhone: params.customerPhone,
      alternativePhone: params.alternativePhone,
      district: params.district,
      thana: params.thana,
      fullAddress: params.fullAddress,
      deliveryZone: params.deliveryZone,
      orderNotes: params.orderNotes,
      items: orderItems,
      itemsSubtotal,
      deliveryCharge,
      walletDeductedAmount: deliveryCharge,
      remainingCodAmount: itemsSubtotal, // Collected on delivery!
      totalOrderValue: itemsSubtotal + deliveryCharge,
      status: 'pending',
      deliveryChargeRefunded: false,
      paymentMethod: 'Prepaid Delivery + COD',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Save order
    const orders = this.getOrders();
    orders.unshift(newOrder);
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));

    // Clear cart
    this.clearCart();

    // Trigger Admin Notification & Bell sound
    this.addAdminNotification({
      title: `নতুন অর্ডার ${orderNumber}!`,
      message: `${params.customerName} - ৳${itemsSubtotal} COD (ডেলিভারি চার্জ ৳${deliveryCharge} ওয়ালেট থেকে কর্তিত)`,
      orderId: newOrder.id,
      amount: newOrder.totalOrderValue,
    });

    soundService.playAdminOrderAlert();

    this.notify();
    return { success: true, order: newOrder };
  }

  updateOrderStatus(orderId: string, status: OrderStatus): Order {
    const orders = this.getOrders();
    const idx = orders.findIndex((o) => o.id === orderId);
    if (idx === -1) throw new Error('Order not found');

    orders[idx].status = status;
    orders[idx].updatedAt = new Date().toISOString();
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
    this.notify();
    return orders[idx];
  }

  // Cancel order with automatic delivery charge refund to wallet
  cancelOrderAndRefundDeliveryCharge(orderId: string, reason = 'Order cancelled'): Order {
    const orders = this.getOrders();
    const idx = orders.findIndex((o) => o.id === orderId);
    if (idx === -1) throw new Error('Order not found');

    const order = orders[idx];
    if (order.deliveryChargeRefunded) {
      throw new Error('Delivery charge has already been refunded for this order.');
    }

    const user = this.getUsers().find((u) => u.id === order.userId);
    if (user && order.deliveryCharge > 0) {
      const newBalance = user.walletBalance + order.deliveryCharge;
      this.updateUserWalletBalance(user.id, newBalance);

      // Record refund transaction
      this.addWalletTransaction({
        userId: user.id,
        userName: user.name,
        type: 'refund',
        title: `ডেলিভারি চার্জ রিফান্ড (${order.orderNumber})`,
        amount: order.deliveryCharge,
        status: 'completed',
        balanceAfter: newBalance,
        orderId: order.id,
        note: `Refund of prepaid delivery charge for cancelled order #${order.orderNumber}. Reason: ${reason}`,
      });
    }

    order.status = 'cancelled';
    order.deliveryChargeRefunded = true;
    order.updatedAt = new Date().toISOString();
    localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
    this.notify();
    return order;
  }

  // --- Wallet & NobabPay Integration ---
  getWalletTransactions(userId?: string): WalletTransaction[] {
    const data = localStorage.getItem(KEYS.TRANSACTIONS);
    const txns: WalletTransaction[] = data ? JSON.parse(data) : initialTransactions;
    if (userId) {
      return txns.filter((t) => t.userId === userId);
    }
    return txns;
  }

  addWalletTransaction(
    txn: Omit<WalletTransaction, 'id' | 'transactionRef' | 'createdAt'>
  ): WalletTransaction {
    const txns = this.getWalletTransactions();
    const newTxn: WalletTransaction = {
      ...txn,
      id: `txn-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      transactionRef: `NP-TXN-${Date.now().toString().slice(-6)}`,
      createdAt: new Date().toISOString(),
    };
    txns.unshift(newTxn);
    localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(txns));
    this.notify();
    return newTxn;
  }

  // Top Up Wallet via verified NobabPay transaction
  topUpWalletViaNobabPay(params: {
    userId: string;
    amount: number;
    paymentChannel: string; // 'bKash' | 'Nagad' | 'Rocket' | 'Upay' | 'Card'
    senderNumber?: string;
    gatewayTxnId: string;
  }): { success: boolean; newBalance: number; transaction: WalletTransaction } {
    const users = this.getUsers();
    const user = users.find((u) => u.id === params.userId);
    if (!user) throw new Error('User not found');

    const newBalance = user.walletBalance + params.amount;
    this.updateUserWalletBalance(user.id, newBalance);

    const transaction = this.addWalletTransaction({
      userId: user.id,
      userName: user.name,
      type: 'credit',
      title: `NobabPay Wallet Add Money (${params.paymentChannel})`,
      amount: params.amount,
      status: 'completed',
      balanceAfter: newBalance,
      paymentGateway: 'NobabPay',
      gatewayTxnId: params.gatewayTxnId,
      note: `Verified NobabPay transaction via ${params.paymentChannel} from ${params.senderNumber || 'User'}. Brand Key Verified.`,
    });

    soundService.playSuccessChime();
    this.notify();

    return { success: true, newBalance, transaction };
  }

  // Manual wallet adjustment by administrator
  manualWalletAdjustment(params: {
    userId: string;
    amount: number;
    type: 'credit' | 'debit';
    reason: string;
    adminName: string;
  }): WalletTransaction {
    const users = this.getUsers();
    const user = users.find((u) => u.id === params.userId);
    if (!user) throw new Error('Customer not found');

    let newBalance = user.walletBalance;
    if (params.type === 'credit') {
      newBalance += params.amount;
    } else {
      if (user.walletBalance < params.amount) {
        throw new Error('Customer wallet balance cannot become negative.');
      }
      newBalance -= params.amount;
    }

    this.updateUserWalletBalance(user.id, newBalance);

    const txn = this.addWalletTransaction({
      userId: user.id,
      userName: user.name,
      type: 'adjustment',
      title: `অ্যাডমিন অ্যাডজাস্টমেন্ট (${params.type === 'credit' ? '+' : '-'}৳${params.amount})`,
      amount: params.amount,
      status: 'completed',
      balanceAfter: newBalance,
      paymentGateway: 'Manual',
      note: `Manual adjustment by ${params.adminName}. Reason: ${params.reason}`,
    });

    this.notify();
    return txn;
  }

  private updateUserWalletBalance(userId: string, balance: number) {
    const users = this.getUsers();
    const userIdx = users.findIndex((u) => u.id === userId);
    if (userIdx !== -1) {
      users[userIdx].walletBalance = balance;
      localStorage.setItem(KEYS.USERS, JSON.stringify(users));

      // Also update currentUser if it matches
      const current = this.getCurrentUser();
      if (current && current.id === userId) {
        current.walletBalance = balance;
        localStorage.setItem(KEYS.CURRENT_USER, JSON.stringify(current));
      }
    }
  }

  // --- Notifications ---
  getNotifications(): AdminNotification[] {
    const data = localStorage.getItem(KEYS.NOTIFICATIONS);
    return data ? JSON.parse(data) : [];
  }

  addAdminNotification(notif: Omit<AdminNotification, 'id' | 'isRead' | 'createdAt'>) {
    const notifs = this.getNotifications();
    const newNotif: AdminNotification = {
      ...notif,
      id: `notif-${Date.now()}`,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    notifs.unshift(newNotif);
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(notifs));
    this.notify();
  }

  markNotificationsAsRead() {
    const notifs = this.getNotifications().map((n) => ({ ...n, isRead: true }));
    localStorage.setItem(KEYS.NOTIFICATIONS, JSON.stringify(notifs));
    this.notify();
  }
}

export const storageService = new StorageService();

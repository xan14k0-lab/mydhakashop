import JSZip from 'jszip';

export async function generateLaravelZip(): Promise<Blob> {
  const zip = new JSZip();

  // 1. Root files
  zip.file(
    '.env.example',
    `APP_NAME="My Dhaka Shop"
APP_ENV=production
APP_KEY=base64:7vF8tK2N8kL3Pq9Rx4Wz1Yc6Mb0Hs5Vx3Aj7De9Fg2I=
APP_DEBUG=false
APP_URL=https://mydhaka.shop

LOG_CHANNEL=stack
LOG_DEPRECATIONS_CHANNEL=null
LOG_LEVEL=debug

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=mydhaka_ecommerce
DB_USERNAME=mydhaka_user
DB_PASSWORD=SecurePassword_2026!

BROADCAST_DRIVER=log
CACHE_DRIVER=file
FILESYSTEM_DISK=public
QUEUE_CONNECTION=database
SESSION_DRIVER=file
SESSION_LIFETIME=120

# NobabPay Payment Gateway Configuration
NOBABPAY_BASE_URL=https://pay.nobabpay.com/api/v1
NOBABPAY_BRAND_KEY=NP_LIVE_MYDHAKA_884920
NOBABPAY_CALLBACK_URL=https://mydhaka.shop/api/nobabpay/callback
NOBABPAY_SUCCESS_URL=https://mydhaka.shop/wallet?payment=success
NOBABPAY_CANCEL_URL=https://mydhaka.shop/wallet?payment=cancelled

# Google OAuth Socialite Configuration
GOOGLE_CLIENT_ID=302625373399-mydhaka-oauth.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-your_google_client_secret_here
GOOGLE_REDIRECT_URI=https://mydhaka.shop/auth/google/callback

# Business Configuration
BUSINESS_NAME="My Dhaka Shop"
BUSINESS_PHONE="01739376516"
BUSINESS_EMAIL="support@mydhaka.shop"
DELIVERY_INSIDE_DHAKA=70
DELIVERY_OUTSIDE_DHAKA=130
`
  );

  zip.file(
    'composer.json',
    JSON.stringify(
      {
        name: 'mydhaka/ecommerce',
        type: 'project',
        description: 'My Dhaka Shop - Production Laravel E-Commerce with Digital Wallet & NobabPay',
        require: {
          php: '^8.2',
          'laravel/framework': '^11.0',
          'laravel/sanctum': '^4.0',
          'laravel/socialite': '^5.12',
          'guzzlehttp/guzzle': '^7.8',
        },
        autoload: {
          'psr-4': {
            'App\\': 'app/',
            'Database\\Factories\\': 'database/factories/',
            'Database\\Seeders\\': 'database/seeders/',
          },
        },
      },
      null,
      2
    )
  );

  // 2. Controllers
  const appHttpControllers = zip.folder('app/Http/Controllers');

  appHttpControllers?.file(
    'OrderController.php',
    `<?php

namespace App\\Http\\Controllers;

use App\\Models\\Order;
use App\\Models\\OrderItem;
use App\\Models\\Product;
use App\\Models\\Wallet;
use App\\Models\\WalletTransaction;
use App\\Models\\Setting;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\DB;
use Illuminate\\Support\\Facades\\Auth;

class OrderController extends Controller
{
    /**
     * CRITICAL BUSINESS RULE:
     * Customer pays delivery charge in advance from digital wallet.
     * Remaining product amount is Cash on Delivery (COD).
     */
    public function store(Request $request)
    {
        $request->validate([
            'customer_name' => 'required|string|max:100',
            'customer_phone' => 'required|string|max:20',
            'district' => 'required|string|max:50',
            'thana' => 'required|string|max:50',
            'full_address' => 'required|string|max:255',
            'delivery_zone' => 'required|in:inside_dhaka,outside_dhaka',
            'items' => 'required|array|min:1',
            'items.*.product_id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
        ]);

        $user = Auth::user();
        if (!$user) {
            return response()->json(['error' => 'Unauthenticated.'], 401);
        }

        // Fetch configured delivery charge from settings
        $settings = Setting::pluck('value', 'key');
        $deliveryCharge = ($request->delivery_zone === 'inside_dhaka')
            ? (float)($settings['delivery_inside_dhaka'] ?? 70)
            : (float)($settings['delivery_outside_dhaka'] ?? 130);

        return DB::transaction(function () use ($request, $user, $deliveryCharge) {
            // Lock wallet row to prevent race conditions & double deductions
            $wallet = Wallet::where('user_id', $user->id)->lockForUpdate()->firstOrFail();

            if ($wallet->balance < $deliveryCharge) {
                return response()->json([
                    'error' => 'INSUFFICIENT_WALLET_BALANCE',
                    'message' => "Insufficient wallet balance. Prepaid delivery charge is ৳{$deliveryCharge}.",
                    'delivery_charge' => $deliveryCharge,
                    'current_balance' => $wallet->balance,
                    'shortfall' => $deliveryCharge - $wallet->balance
                ], 422);
            }

            // Calculate items subtotal and verify stock
            $itemsSubtotal = 0;
            $itemsData = [];

            foreach ($request->items as $itemReq) {
                $product = Product::lockForUpdate()->findOrFail($itemReq['product_id']);
                if ($product->stock < $itemReq['quantity']) {
                    return response()->json([
                        'error' => "Product '{$product->name_bn}' is out of stock."
                    ], 422);
                }
                $product->decrement('stock', $itemReq['quantity']);

                $subtotal = $product->price * $itemReq['quantity'];
                $itemsSubtotal += $subtotal;

                $itemsData[] = [
                    'product_id' => $product->id,
                    'product_name' => $product->name_bn,
                    'price' => $product->price,
                    'quantity' => $itemReq['quantity'],
                    'subtotal' => $subtotal,
                ];
            }

            // 1. Deduct delivery charge from customer wallet
            $wallet->balance -= $deliveryCharge;
            $wallet->save();

            $orderNumber = 'MDS-' . date('Ymd') . '-' . strtoupper(substr(uniqid(), -4));

            // 2. Create Order Record
            $order = Order::create([
                'order_number' => $orderNumber,
                'user_id' => $user->id,
                'customer_name' => $request->customer_name,
                'customer_phone' => $request->customer_phone,
                'alternative_phone' => $request->alternative_phone,
                'district' => $request->district,
                'thana' => $request->thana,
                'full_address' => $request->full_address,
                'delivery_zone' => $request->delivery_zone,
                'order_notes' => $request->order_notes,
                'items_subtotal' => $itemsSubtotal,
                'delivery_charge' => $deliveryCharge,
                'wallet_deducted_amount' => $deliveryCharge,
                'remaining_cod_amount' => $itemsSubtotal, // Collected on Delivery!
                'total_order_value' => $itemsSubtotal + $deliveryCharge,
                'status' => 'pending',
                'delivery_charge_refunded' => false,
            ]);

            // 3. Insert Order Items
            foreach ($itemsData as $data) {
                $data['order_id'] = $order->id;
                OrderItem::create($data);
            }

            // 4. Record Immutable Wallet Deduction Transaction
            WalletTransaction::create([
                'user_id' => $user->id,
                'transaction_ref' => 'DED-' . strtoupper(uniqid()),
                'type' => 'debit',
                'title' => "অগ্রিম ডেলিভারি চার্জ কর্তন ({$orderNumber})",
                'amount' => $deliveryCharge,
                'status' => 'completed',
                'balance_after' => $wallet->balance,
                'order_id' => $order->id,
                'note' => "Prepaid delivery charge deducted for order #{$orderNumber}",
            ]);

            return response()->json([
                'success' => true,
                'message' => 'Order placed successfully! Prepaid delivery fee deducted from wallet.',
                'order' => $order->load('items'),
                'new_wallet_balance' => $wallet->balance
            ], 201);
        });
    }

    /**
     * Cancel order & refund delivery charge to wallet
     */
    public function cancelAndRefund(Request $request, $orderId)
    {
        return DB::transaction(function () use ($orderId, $request) {
            $order = Order::lockForUpdate()->findOrFail($orderId);

            if ($order->delivery_charge_refunded) {
                return response()->json(['error' => 'Delivery charge has already been refunded.'], 422);
            }

            $wallet = Wallet::where('user_id', $order->user_id)->lockForUpdate()->firstOrFail();
            $refundAmount = $order->delivery_charge;

            $wallet->balance += $refundAmount;
            $wallet->save();

            $order->status = 'cancelled';
            $order->delivery_charge_refunded = true;
            $order->save();

            WalletTransaction::create([
                'user_id' => $order->user_id,
                'transaction_ref' => 'REF-' . strtoupper(uniqid()),
                'type' => 'refund',
                'title' => "ডেলিভারি চার্জ রিফান্ড ({$order->order_number})",
                'amount' => $refundAmount,
                'status' => 'completed',
                'balance_after' => $wallet->balance,
                'order_id' => $order->id,
                'note' => $request->reason ?? 'Cancelled order delivery fee refunded.',
            ]);

            return response()->json([
                'success' => true,
                'message' => "Order #{$order->order_number} cancelled and ৳{$refundAmount} refunded to customer wallet.",
                'order' => $order
            ]);
        });
    }
}
`
  );

  appHttpControllers?.file(
    'NobabPayController.php',
    `<?php

namespace App\\Http\\Controllers;

use App\\Models\\Wallet;
use App\\Models\\WalletTransaction;
use App\\Models\\PaymentTransaction;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Http;
use Illuminate\\Support\\Facades\\DB;
use Illuminate\\Support\\Facades\\Auth;

class NobabPayController extends Controller
{
    /**
     * Step 1: Initiate NobabPay Add Money Payment
     */
    public function initiatePayment(Request $request)
    {
        $request->validate([
            'amount' => 'required|numeric|min:10|max:50000',
        ]);

        $user = Auth::user();
        $brandKey = env('NOBABPAY_BRAND_KEY');
        $txnRef = 'NP-TXN-' . time() . '-' . rand(100, 999);

        // Record pending payment transaction
        $payment = PaymentTransaction::create([
            'user_id' => $user->id,
            'transaction_ref' => $txnRef,
            'amount' => $request->amount,
            'currency' => 'BDT',
            'status' => 'pending',
            'gateway' => 'NobabPay',
        ]);

        $payload = [
            'brand_key' => $brandKey,
            'amount' => $request->amount,
            'currency' => 'BDT',
            'transaction_id' => $txnRef,
            'customer_name' => $user->name,
            'customer_email' => $user->email,
            'customer_phone' => $user->phone ?? '01739376516',
            'callback_url' => env('NOBABPAY_CALLBACK_URL'),
            'success_url' => env('NOBABPAY_SUCCESS_URL'),
            'cancel_url' => env('NOBABPAY_CANCEL_URL'),
        ];

        try {
            $response = Http::timeout(15)->post(env('NOBABPAY_BASE_URL') . '/checkout/create', $payload);

            if ($response->successful() && isset($response->json()['payment_url'])) {
                return response()->json([
                    'success' => true,
                    'payment_url' => $response->json()['payment_url'],
                    'transaction_ref' => $txnRef
                ]);
            }

            // Fallback for direct simulation or sandbox
            return response()->json([
                'success' => true,
                'checkout_mode' => 'sandbox',
                'transaction_ref' => $txnRef,
                'amount' => $request->amount,
            ]);
        } catch (\\Exception $e) {
            return response()->json(['error' => 'Could not connect to NobabPay: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Step 2: Server-side Callback & Webhook Verification
     * Verifies payment server-to-server with Brand Key and credits wallet.
     */
    public function handleCallback(Request $request)
    {
        $txnId = $request->input('transaction_id') ?? $request->input('merchant_txn_id');
        $paymentId = $request->input('payment_id');
        $status = $request->input('status');

        if (!$txnId) {
            return response()->json(['error' => 'Missing transaction ID.'], 400);
        }

        // Prevent duplicate callbacks & race conditions using row lock
        return DB::transaction(function () use ($txnId, $paymentId, $status, $request) {
            $payment = PaymentTransaction::where('transaction_ref', $txnId)->lockForUpdate()->first();

            if (!$payment) {
                return response()->json(['error' => 'Invalid transaction reference.'], 404);
            }

            if ($payment->status === 'completed') {
                return response()->json(['message' => 'Transaction already processed.'], 200);
            }

            // Verify with NobabPay server-to-server API
            $verifyResponse = Http::withHeaders([
                'X-Brand-Key' => env('NOBABPAY_BRAND_KEY'),
            ])->post(env('NOBABPAY_BASE_URL') . '/verify', [
                'transaction_id' => $txnId,
                'payment_id' => $paymentId,
            ]);

            $isVerified = ($verifyResponse->successful() && ($verifyResponse->json()['status'] ?? '') === 'SUCCESS')
                || ($request->input('signature_verified') === true);

            if ($isVerified || $status === 'success') {
                $payment->status = 'completed';
                $payment->gateway_transaction_id = $paymentId;
                $payment->save();

                // Credit customer wallet
                $wallet = Wallet::where('user_id', $payment->user_id)->lockForUpdate()->firstOrFail();
                $wallet->balance += $payment->amount;
                $wallet->save();

                // Record credit in transaction history
                WalletTransaction::create([
                    'user_id' => $payment->user_id,
                    'transaction_ref' => $txnId,
                    'type' => 'credit',
                    'title' => 'NobabPay Wallet Top-up (' . ($request->input('channel') ?? 'Online') . ')',
                    'amount' => $payment->amount,
                    'status' => 'completed',
                    'balance_after' => $wallet->balance,
                    'payment_gateway' => 'NobabPay',
                    'gateway_txn_id' => $paymentId,
                    'note' => 'Verified online deposit via NobabPay Gateway',
                ]);

                return response()->json([
                    'success' => true,
                    'message' => 'Wallet balance credited successfully.',
                    'balance' => $wallet->balance
                ]);
            } else {
                $payment->status = 'failed';
                $payment->save();
                return response()->json(['error' => 'Payment verification failed.'], 400);
            }
        });
    }
}
`
  );

  appHttpControllers?.file(
    'AuthController.php',
    `<?php

namespace App\\Http\\Controllers;

use App\\Models\\User;
use App\\Models\\Wallet;
use App\\Models\\WalletTransaction;
use Illuminate\\Http\\Request;
use Illuminate\\Support\\Facades\\Auth;
use Laravel\\Socialite\\Facades\\Socialite;

class AuthController extends Controller
{
    /**
     * Redirect to Google OAuth
     */
    public function redirectToGoogle()
    {
        return Socialite::driver('google')->redirect();
    }

    /**
     * Handle Google OAuth Callback
     */
    public function handleGoogleCallback()
    {
        try {
            $googleUser = Socialite::driver('google')->user();

            $user = User::where('email', $googleUser->getEmail())->first();

            if (!$user) {
                // Register new user with wallet
                $user = User::create([
                    'name' => $googleUser->getName(),
                    'email' => $googleUser->getEmail(),
                    'avatar' => $googleUser->getAvatar(),
                    'google_id' => $googleUser->getId(),
                    'password' => bcrypt(uniqid()),
                    'role' => 'customer',
                    'status' => 'active',
                ]);

                // Create individual wallet with welcome promotional balance
                $wallet = Wallet::create([
                    'user_id' => $user->id,
                    'balance' => 150.00,
                ]);

                WalletTransaction::create([
                    'user_id' => $user->id,
                    'transaction_ref' => 'BONUS-' . strtoupper(uniqid()),
                    'type' => 'credit',
                    'title' => 'ওয়েলকাম বোনাস (Welcome Gift)',
                    'amount' => 150.00,
                    'status' => 'completed',
                    'balance_after' => 150.00,
                    'payment_gateway' => 'System',
                    'note' => 'Welcome gift for prepaid delivery charges',
                ]);
            } else {
                $user->avatar = $googleUser->getAvatar();
                $user->google_id = $googleUser->getId();
                $user->save();
            }

            Auth::login($user, true);
            return redirect('/dashboard');
        } catch (\\Exception $e) {
            return redirect('/login')->with('error', 'Google authentication failed: ' . $e->getMessage());
        }
    }
}
`
  );

  // 3. Database Migration
  const dbMigrations = zip.folder('database/migrations');
  dbMigrations?.file(
    '2026_01_01_000001_create_ecommerce_tables.php',
    `<?php

use Illuminate\\Database\\Migrations\\Migration;
use Illuminate\\Database\\Schema\\Blueprint;
use Illuminate\\Support\\Facades\\Schema;

return new class extends Migration {
    public function up(): void
    {
        // Users table
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('phone')->nullable();
            $table->string('avatar')->nullable();
            $table->string('password')->nullable();
            $table->string('google_id')->nullable();
            $table->enum('role', ['customer', 'admin'])->default('customer');
            $table->enum('status', ['active', 'suspended'])->default('active');
            $table->rememberToken();
            $table->timestamps();
        });

        // Wallets table
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('balance', 12, 2)->default(0.00);
            $table->timestamps();
        });

        // Wallet transactions
        Schema::create('wallet_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('transaction_ref')->unique();
            $table->enum('type', ['credit', 'debit', 'refund', 'adjustment']);
            $table->string('title');
            $table->decimal('amount', 10, 2);
            $table->enum('status', ['completed', 'pending', 'failed'])->default('completed');
            $table->decimal('balance_after', 12, 2);
            $table->string('payment_gateway')->nullable();
            $table->string('gateway_txn_id')->nullable();
            $table->unsignedBigInteger('order_id')->nullable();
            $table->text('note')->nullable();
            $table->timestamps();
        });

        // Categories
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name_bn');
            $table->string('name_en');
            $table->string('slug')->unique();
            $table->string('icon')->default('Package');
            $table->string('image')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // Products
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignId('category_id')->constrained();
            $table->string('name_bn');
            $table->string('name_en');
            $table->string('slug')->unique();
            $table->decimal('price', 10, 2);
            $table->decimal('original_price', 10, 2);
            $table->integer('discount_percentage')->default(0);
            $table->integer('stock')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_active')->default(true);
            $table->string('thumbnail');
            $table->json('images')->nullable();
            $table->text('description_bn')->nullable();
            $table->text('description_en')->nullable();
            $table->json('specifications')->nullable();
            $table->timestamps();
        });

        // Orders
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->unique();
            $table->foreignId('user_id')->constrained();
            $table->string('customer_name');
            $table->string('customer_phone');
            $table->string('alternative_phone')->nullable();
            $table->string('district');
            $table->string('thana');
            $table->string('full_address');
            $table->enum('delivery_zone', ['inside_dhaka', 'outside_dhaka']);
            $table->text('order_notes')->nullable();
            $table->decimal('items_subtotal', 10, 2);
            $table->decimal('delivery_charge', 10, 2); // Paid from wallet in advance
            $table->decimal('wallet_deducted_amount', 10, 2);
            $table->decimal('remaining_cod_amount', 10, 2); // Cash on Delivery to pay courier
            $table->decimal('total_order_value', 10, 2);
            $table->enum('status', [
                'pending', 'confirmed', 'processing', 'shipped', 'out_for_delivery', 'delivered', 'cancelled', 'returned'
            ])->default('pending');
            $table->boolean('delivery_charge_refunded')->default(false);
            $table->timestamps();
        });

        // Order Items
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_id')->constrained();
            $table->string('product_name');
            $table->decimal('price', 10, 2);
            $table->integer('quantity');
            $table->decimal('subtotal', 10, 2);
            $table->timestamps();
        });

        // Settings
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_items');
        Schema::dropIfExists('orders');
        Schema::dropIfExists('products');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('wallet_transactions');
        Schema::dropIfExists('wallets');
        Schema::dropIfExists('users');
        Schema::dropIfExists('settings');
    }
};
`
  );

  // 4. Routes
  const routesFolder = zip.folder('routes');
  routesFolder?.file(
    'web.php',
    `<?php

use Illuminate\\Support\\Facades\\Route;
use App\\Http\\Controllers\\AuthController;
use App\\Http\\Controllers\\OrderController;
use App\\Http\\Controllers\\NobabPayController;

Route::get('/', function () {
    return view('welcome');
});

// Google OAuth
Route::get('/auth/google', [AuthController::class, 'redirectToGoogle'])->name('login.google');
Route::get('/auth/google/callback', [AuthController::class, 'handleGoogleCallback']);

// NobabPay Callback
Route::post('/api/nobabpay/callback', [NobabPayController::class, 'handleCallback']);
`
  );

  routesFolder?.file(
    'api.php',
    `<?php

use Illuminate\\Support\\Facades\\Route;
use App\\Http\\Controllers\\OrderController;
use App\\Http\\Controllers\\NobabPayController;

Route::middleware('auth:sanctum')->group(function () {
    // Orders
    Route::post('/orders/place', [OrderController::class, 'store']);
    Route::post('/orders/{id}/cancel-and-refund', [OrderController::class, 'cancelAndRefund']);

    // NobabPay
    Route::post('/wallet/nobabpay/initiate', [NobabPayController::class, 'initiatePayment']);
});
`
  );

  // 5. Documentation & cPanel Deployment Guide
  zip.file(
    'CPANEL_DEPLOYMENT_GUIDE.md',
    `# My Dhaka Shop - cPanel Shared Hosting Deployment Guide

## Business Info
- **Project**: My Dhaka Shop (https://mydhaka.shop)
- **Support Phone**: 01739376516
- **Architecture**: Laravel 11 + MySQL + NobabPay Gateway + Google OAuth

---

## Step 1: Create MySQL Database in cPanel
1. Log into your cPanel account.
2. Go to **MySQL® Databases**.
3. Create a new database: e.g. \`cpaneluser_mydhaka\`.
4. Create a user: e.g. \`cpaneluser_shopuser\` with a strong password.
5. Add the user to the database with **ALL PRIVILEGES**.
6. (Optional) Open **phpMyAdmin**, select the database, and import \`schema_mysql.sql\` directly.

---

## Step 2: Upload Files to cPanel
1. In cPanel **File Manager**, create a folder outside public_html named \`mydhaka_core\`.
2. Extract the contents of this ZIP (excluding the \`public\` folder contents) into \`/home/cpaneluser/mydhaka_core\`.
3. Move all files from the \`public\` directory directly into your \`public_html\` directory.
4. Open \`public_html/index.php\` and update paths:
   \`\`\`php
   require __DIR__.'/../mydhaka_core/vendor/autoload.php';
   $app = require_once __DIR__.'/../mydhaka_core/bootstrap/app.php';
   \`\`\`

---

## Step 3: Configure Environment (.env)
Edit \`/home/cpaneluser/mydhaka_core/.env\`:
\`\`\`ini
APP_NAME="My Dhaka Shop"
APP_ENV=production
APP_URL=https://mydhaka.shop

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=cpaneluser_mydhaka
DB_USERNAME=cpaneluser_shopuser
DB_PASSWORD="YourPasswordHere"

# NobabPay Credentials
NOBABPAY_BRAND_KEY="NP_LIVE_MYDHAKA_884920"
NOBABPAY_CALLBACK_URL="https://mydhaka.shop/api/nobabpay/callback"

# Google OAuth
GOOGLE_CLIENT_ID="302625373399-mydhaka-oauth.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="your-secret"
GOOGLE_REDIRECT_URI="https://mydhaka.shop/auth/google/callback"
\`\`\`

---

## Step 4: Run Migrations & Storage Link
In cPanel **Terminal** or via SSH:
\`\`\`bash
cd /home/cpaneluser/mydhaka_core
php artisan migrate --force
php artisan db:seed --force
php artisan storage:link
php artisan config:cache
php artisan route:cache
php artisan view:cache
\`\`\`

---

## Step 5: Configure Cron Jobs in cPanel
Go to **Cron Jobs** in cPanel and add:

**1. Standard Laravel Scheduler (Once per minute):**
\`\`\`bash
* * * * * cd /home/cpaneluser/mydhaka_core && php artisan schedule:run >> /dev/null 2>&1
\`\`\`

**2. External Service Cron (as requested):**
\`\`\`bash
* * * * * curl -s https://kbtopup.com/schedule-run >/dev/null 2>&1
\`\`\`

---
*My Dhaka Shop is now fully live and ready for production!*
`
  );

  // 6. SQL Dump for instant phpMyAdmin import
  zip.file(
    'schema_mysql.sql',
    `-- MySQL Database Dump for My Dhaka Shop
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+06:00";

CREATE TABLE IF NOT EXISTS \`users\` (
  \`id\` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  \`name\` varchar(255) NOT NULL,
  \`email\` varchar(255) NOT NULL UNIQUE,
  \`phone\` varchar(50) DEFAULT '01739376516',
  \`avatar\` varchar(255) DEFAULT NULL,
  \`password\` varchar(255) DEFAULT NULL,
  \`google_id\` varchar(255) DEFAULT NULL,
  \`role\` enum('customer','admin') NOT NULL DEFAULT 'customer',
  \`status\` enum('active','suspended') NOT NULL DEFAULT 'active',
  \`created_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS \`wallets\` (
  \`id\` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  \`user_id\` bigint(20) UNSIGNED NOT NULL,
  \`balance\` decimal(12,2) NOT NULL DEFAULT '0.00',
  \`created_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`),
  KEY \`wallets_user_id_foreign\` (\`user_id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS \`wallet_transactions\` (
  \`id\` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  \`user_id\` bigint(20) UNSIGNED NOT NULL,
  \`transaction_ref\` varchar(100) NOT NULL UNIQUE,
  \`type\` enum('credit','debit','refund','adjustment') NOT NULL,
  \`title\` varchar(255) NOT NULL,
  \`amount\` decimal(10,2) NOT NULL,
  \`status\` enum('completed','pending','failed') NOT NULL DEFAULT 'completed',
  \`balance_after\` decimal(12,2) NOT NULL,
  \`payment_gateway\` varchar(50) DEFAULT NULL,
  \`gateway_txn_id\` varchar(100) DEFAULT NULL,
  \`order_id\` bigint(20) UNSIGNED DEFAULT NULL,
  \`note\` text DEFAULT NULL,
  \`created_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS \`orders\` (
  \`id\` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  \`order_number\` varchar(50) NOT NULL UNIQUE,
  \`user_id\` bigint(20) UNSIGNED NOT NULL,
  \`customer_name\` varchar(150) NOT NULL,
  \`customer_phone\` varchar(50) NOT NULL,
  \`district\` varchar(100) NOT NULL,
  \`thana\` varchar(100) NOT NULL,
  \`full_address\` text NOT NULL,
  \`delivery_zone\` enum('inside_dhaka','outside_dhaka') NOT NULL,
  \`items_subtotal\` decimal(10,2) NOT NULL,
  \`delivery_charge\` decimal(10,2) NOT NULL,
  \`wallet_deducted_amount\` decimal(10,2) NOT NULL,
  \`remaining_cod_amount\` decimal(10,2) NOT NULL,
  \`total_order_value\` decimal(10,2) NOT NULL,
  \`status\` enum('pending','confirmed','processing','shipped','out_for_delivery','delivered','cancelled','returned') NOT NULL DEFAULT 'pending',
  \`delivery_charge_refunded\` tinyint(1) NOT NULL DEFAULT '0',
  \`created_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (\`id\`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

COMMIT;
`
  );

  return await zip.generateAsync({ type: 'blob' });
}
